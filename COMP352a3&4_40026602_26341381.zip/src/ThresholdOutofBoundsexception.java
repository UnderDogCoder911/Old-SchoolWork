package src;

public class ThresholdOutofBoundsexception extends Exception {
	private String msg;
	public ThresholdOutofBoundsexception() {
		msg = "The Threshold cannot be smaller than 100 or bigger than 500000";
	}
}
