package src;

public class RandomStrings {

	static String getAlphaNumericString (int n) {
		String AlphaNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
	
	StringBuilder makeString = new StringBuilder(n);
	
	for(int i = 0; i < n; i++) {
		int index = (int)(AlphaNum.length() * Math.random());
		
		makeString.append(AlphaNum.charAt(index));
	}
	return makeString.toString();
	}
	
	
	}
