package src;

import java.util.LinkedList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
public class TestMain {
	
	public static void main(String[] args) {
		RandomStrings rs = new RandomStrings();
		
		try {
			System.out.println("--------------------Test AR 1----------------------");
			SmartAR myAR = new SmartAR(100, 200, 6);
			myAR.add(rs.getAlphaNumericString(6), "Dodge");
			String[] trying = myAR.allKeys();
			System.out.println("The original amount of SmartAR keys is " + trying.length);
			myAR.remove(trying[100]);
			trying = myAR.allKeys();
			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
//			for(String k : trying) {
//				System.out.println(k);
//			}
			String val = myAR.getValues(trying[0]);
			System.out.println("The make obtained from getValues is: " + val);
			String next = myAR.nextKey(trying[99]);
			System.out.println("Trying nextkey method: "+ next);
			String prev = myAR.prevKey(trying[0]);
			System.out.println("Trying prevkey method: "+ prev);
			LinkedList prevCars = myAR.previousCars(trying[99]);
			for (int i = prevCars.size()-1; i >= 0; i--) { 	
			System.out.println(prevCars.get(i));
			}
			
			
//			System.out.println("--------------------Test AR 2----------------------");
//			myAR = new SmartAR(300, 200, 6);
//			myAR.add(rs.getAlphaNumericString(6), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[200]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[56]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[212]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 3----------------------");
//			myAR = new SmartAR(100, 200, 12);
//			myAR.add(rs.getAlphaNumericString(12), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}	
			
//			System.out.println("--------------------Test AR 4----------------------");
//			myAR = new SmartAR(250, 200, 12);
//			myAR.add(rs.getAlphaNumericString(12), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 5----------------------");
//			myAR = new SmartAR(500000, 2500, 6);
//			myAR.add(rs.getAlphaNumericString(6), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[1200]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[3000]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[10]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//				System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 6----------------------");
//			myAR = new SmartAR(500000, 500000, 6);
//			myAR.add(rs.getAlphaNumericString(6), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[10202]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[7554]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//				System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 7----------------------");
//			myAR = new SmartAR(100000, 200000, 10);
//			myAR.add(rs.getAlphaNumericString(10), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[4576]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[1283]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[101]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//				System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 8----------------------");
//			myAR = new SmartAR(300000, 400000, 7);
//			myAR.add(rs.getAlphaNumericString(7), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 9----------------------");
//			myAR = new SmartAR(100, 200, 8);
//			myAR.add(rs.getAlphaNumericString(8), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}
			
//			System.out.println("--------------------Test AR 10----------------------");
//			myAR = new SmartAR(100, 200, 6);
//			myAR.add(rs.getAlphaNumericString(6), "Dodge");
//			trying = myAR.allKeys();
//			System.out.println("The original amount of SmartAR keys is " + trying.length);
//			myAR.remove(trying[100]);
//			trying = myAR.allKeys();
//			System.out.println("The after removal, the amount of SmartAR keys is " + trying.length);
////			for(String k : trying) {
////				System.out.println(k);
////			}
//			val = myAR.getValues(trying[0]);
//			System.out.println("The make obtained from getValues is: " + val);
//			next = myAR.nextKey(trying[99]);
//			System.out.println("Trying nextkey method: "+ next);
//			prev = myAR.prevKey(trying[0]);
//			System.out.println("Trying prevkey method: "+ prev);
//			prevCars = myAR.previousCars(trying[99]);
//			for (int i = prevCars.size()-1; i >= 0; i--) { 	
//			System.out.println(prevCars.get(i));
//			}
			System.out.println("--------------------Test file1----------------------");
			File TestF1 = new File("../Assignment3and4COMP352/src/ar_test_file1.txt");
			File TestF2 = new File("../Assignment3and4COMP352/src/ar_test_file2.txt");
			File TestF3 = new File("../Assignment3and4COMP352/src/ar_test_file3.txt");
			Scanner sc1 = new Scanner(TestF1);
			Scanner sc2 = new Scanner(TestF2);
			Scanner sc3 = new Scanner(TestF3);
			
			String str = "";
			ArrayList<String> Keys = new ArrayList<>(); 
			while(sc1.hasNextLine()) {
				str = sc1.nextLine();
				Keys.add(str);
			}
			sc1.close();
			SmartAR TestAR1 = new SmartAR(); 
			for (int i = 0; i < Keys.size(); i ++) {
				KVpair test = new KVpair(Keys.get(i));
				TestAR1.add(test.getKey(), test.RandValue());
			}
			
			
			String[] AR1Keys = TestAR1.allKeys();
			System.out.println("The amount of keys within the hashtable is: " + AR1Keys.length);
			
			TestAR1.remove(AR1Keys[1]);
			AR1Keys = TestAR1.allKeys();
			System.out.println("With removal, the amount of keys within the hashtable is: " + AR1Keys.length);
			
			String someval = TestAR1.getValues(AR1Keys[4000]);
			System.out.println("The getValues method returns: " + someval);
			String somenext = TestAR1.nextKey(AR1Keys[66]);
			System.out.println("The nextKey method returns: " + somenext);
			String someprev = TestAR1.prevKey(AR1Keys[6857]);
			System.out.println("The prevKey method returns: " + someprev); 
			LinkedList somePrevCars = TestAR1.previousCars(AR1Keys[0]);
			for (int i = somePrevCars.size()-1; i >= 0; i--) { 	
					System.out.println(somePrevCars.get(i));
				}
//			System.out.println("--------------------Test file2----------------------");
//			str = "";
//			Keys = new ArrayList<>(); 
//			while(sc2.hasNextLine()) {
//				str = sc2.nextLine();
//				Keys.add(str);
//			}
//			sc2.close();
//			SmartAR TestAR2 = new SmartAR(); 
//			for (int i = 0; i < Keys.size(); i ++) {
//				KVpair test = new KVpair(Keys.get(i));
//				TestAR2.add(test.getKey(), test.RandValue());
//			}
//			
//			
//			String[] AR2Keys = TestAR2.allKeys();
//			System.out.println("The amount of keys within the hashtable is: " + AR1Keys.length);
//			
//			TestAR2.remove(AR2Keys[1]);
//			AR2Keys = TestAR2.allKeys();
//			System.out.println("With removal, the amount of keys within the hashtable is: " + AR1Keys.length);
//			
//			someval = TestAR2.getValues(AR2Keys[4000]);
//			System.out.println("The getValues method returns: " + someval);
//			somenext = TestAR2.nextKey(AR2Keys[66]);
//			System.out.println("The nextKey method returns: " + somenext);
//			someprev = TestAR2.prevKey(AR2Keys[6857]);
//			System.out.println("The prevKey method returns: " + someprev); 
//			somePrevCars = TestAR2.previousCars(AR2Keys[0]);
//			for (int i = somePrevCars.size()-1; i >= 0; i--) { 	
//					System.out.println(somePrevCars.get(i));
//				}
			
//			System.out.println("--------------------Test file3----------------------");
//			str = "";
//			Keys = new ArrayList<>(); 
//			while(sc3.hasNextLine()) {
//				str = sc3.nextLine();
//				Keys.add(str);
//			}
//			sc3.close();
//			SmartAR TestAR3 = new SmartAR(); 
//			for (int i = 0; i < Keys.size(); i ++) {
//				KVpair test = new KVpair(Keys.get(i));
//				TestAR3.add(test.getKey(), test.RandValue());
//			}
//			
//			
//			String[] AR3Keys = TestAR3.allKeys();
//			System.out.println("The amount of keys within the hashtable is: " + AR1Keys.length);
//			
//			TestAR3.remove(AR3Keys[1]);
//			AR3Keys = TestAR3.allKeys();
//			System.out.println("With removal, the amount of keys within the hashtable is: " + AR1Keys.length);
//			
//			someval = TestAR3.getValues(AR3Keys[4000]);
//			System.out.println("The getValues method returns: " + someval);
//			somenext = TestAR3.nextKey(AR3Keys[66]);
//			System.out.println("The nextKey method returns: " + somenext);
//			someprev = TestAR3.prevKey(AR3Keys[6857]);
//			System.out.println("The prevKey method returns: " + someprev); 
//			somePrevCars = TestAR3.previousCars(AR3Keys[0]);
//			for (int i = somePrevCars.size()-1; i >= 0; i--) { 	
//					System.out.println(somePrevCars.get(i));
//			}

		} catch (ThresholdOutofBoundsexception e) {
			
			e.printStackTrace();
		}catch (invalidKeylengthException e) {
			 
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	
	}

}
