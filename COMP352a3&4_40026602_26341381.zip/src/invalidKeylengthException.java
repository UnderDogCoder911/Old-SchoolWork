package src;

public class invalidKeylengthException extends Exception {
	private String msg;
	public invalidKeylengthException() {
		msg = "The Key length can only be between length 6 and 12";
	}
}
