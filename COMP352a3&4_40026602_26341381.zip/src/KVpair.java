package src;

import java.util.Random;

public class KVpair {
	private String Key;
	private String[] VALUE = {"Honda", "Dodge", "Ford", "Toyota", "Nissan",
			"Chevrolet", "Subaru", "Infinity", "Lotus", "McLaren"
			, "Hyundai", "Mitsubishi"};
	private String userVal;
	
	public KVpair(String Key) {
		this.Key = Key;
	}
	public KVpair(String Key, String val) {
		this.Key = Key;
		if(checkuserval(val)) {
			userVal = val;
		}else {
			System.out.println("Not a make!");
			System.exit(0);
		}
		
	}
	
	public boolean checkuserval(String val) {
		boolean flag = false;
		
		for (int i = 0; i < VALUE.length; i ++) {
			if (VALUE[i].toLowerCase().equals(val.toLowerCase())) {
				flag = true;
			}else continue;
		}
		 return flag;
	}
	public String[] getVALUE() {
		return VALUE;
	}
	public String getKey() {
		return Key;
	}

	public void setKey(String key) {
		Key = key;
	}
	public boolean setuserVal(String val) {
		boolean flag = false;
		
		if(checkuserval(val)) {
			userVal = val;
			flag = true;
		}
		return flag;
	}
	
	public String getuserVal() {
		return userVal;
	}
	public String RandValue() {
		int Randommake = new Random().nextInt(VALUE.length);
		return VALUE[Randommake];
	}

	
	public String toString() {
		String Answer = "";
		Answer += Key;
		Answer = Answer +", " + userVal;
		return Answer;
	}
}
