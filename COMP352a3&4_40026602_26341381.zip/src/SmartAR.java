package src;
import java.util.LinkedList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

public class SmartAR {
	private int threshold;
	private int Keylength;
	private int amtcars;
	private LinkedList<KVpair> LList;
	private Hashtable HTab;
	private LinkedList<KVpair> History;

	//Default constuctor that sets threshold to arbitary value
	//The hashtable is initialized because the Threshold is 100 and any
	//SmartAR with number of Keys >= Threshold will be a Hashtable 
	public SmartAR() throws ThresholdOutofBoundsexception {
		amtcars = 0;
		Keylength = 12;
		threshold = 100;
		HTab = new Hashtable();
	}
	
	//parameterized constructor
	//setKeyLength and Threshold are used in order to check for exception conditions
	public SmartAR(int size, int Threshold, int klen) throws ThresholdOutofBoundsexception, invalidKeylengthException {
	amtcars = size;
	this.setKeyLength(klen);
	this.setThreshold(Threshold);
		
	//depending on the size and the threshold SmartAR will be a LinkList or a Hashtable
	 if(size < threshold) {
		 LList = new LinkedList<>();
		
	 } else if (size >= threshold){
		 HTab = new Hashtable<>(amtcars);
		
	 }
	 //Random Keys and Car models will be generated
	 generate(amtcars);
	 
	}
	int partition(String arr[], int low, int high) {
        String pivot = arr[high];
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        {
            // If current element is smaller than the pivot
            if (arr[j].compareToIgnoreCase(pivot) < 0)
            {
                i++;

                // swap arr[i] and arr[j]
                String temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        String temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }

    void quickSort(String arr[], int low, int high) {
        if (low < high)
        {
            int pi = partition(arr, low, high);

            // Recursively sort elements before
            // partition and after partition
            quickSort(arr, low, pi-1);
            quickSort(arr, pi+1, high);
        }
    }

    void merge(String[] myA, int l, int m, int r) {
        //sizes of both arrays left and right arrays
        int ls = m - l + 1;
        int rs = r - m;
        
        String[]Left = new String[ls];
        String[]Right = new String[rs];
        
        //Strings from the subarray to be merged are split into Left and Right Arrays
        for(int i = 0; i < ls; i++) {
            Left[i] = myA[l + i];
            }
        for(int j = 0; j < rs; j++) {
            Right[j] = myA[m + 1 + j];
        }
        
        int li = 0, ri = 0;
        
        int mi = l;
        
        //Going through each element within both Left and Right Array
        //we compare values
        while(li < ls && ri < rs) {
        	//if the Left value is lexicographically smaller
            if(Left[li].compareTo(Right[ri]) <= 0) {
                
            	//it is merged back into the subarray
            	myA[mi] = Left[li];
                li++;
                
            } else {
                //else it is the Right values that is placed first
                myA[mi] = Right[ri];
                ri++;
            }
            mi++;
        }
        
        //if we compare all values from Right and there are still values left in Left
        while(li < ls) {
        	//they are dumped in order since they are all larger Lexicographically
            myA[mi] = Left[li];
            li++;
            mi++;
        }
        
        //same logic as above but if Left is empty and values remain in Right
        while(ri < rs) {
            myA[mi] = Right[ri];
            ri++;
            mi++;
        }
    }

    void mergeSort(String myA[], int l, int r) {
        //acts as while(left index is smaller than right)
    	if (l < r) {
    		//the Array will be split down the middle using this value
            int mid = (l+r)/2;
            
            //the function is recursively called to split left
            mergeSort(myA, l, mid);
            //and right halfs of the original array up until their base components
            mergeSort(myA, mid+1, r);
            
            //it is then merged back into the original array
            merge(myA, l, mid, r);
        }
    }
    //Sets the threshold as defined in the assignment
	public void setThreshold(int Threshold) throws ThresholdOutofBoundsexception {
		if (Threshold < 100 || Threshold > 500000) {
			throw new ThresholdOutofBoundsexception();
		}
		
		threshold = Threshold;
		
	}
	
	//sets the length of keys as defined in the assignment
	public void setKeyLength(int Length) throws invalidKeylengthException {
		if(Length < 6 || Length > 12) {
			throw new invalidKeylengthException();
		}
		Keylength = Length;
	}
	

	//to generate random values
	public void generate(int n) {
		RandomStrings rs = new RandomStrings();
		
		//checking whether SmartAR is a Linked List or HashTable
		if(!(LList == null)) {
		for (int i = 0; i < n; i++) {
			//Creates a Key Value Pair object
			KVpair kv = new KVpair(rs.getAlphaNumericString(Keylength));
			
			//the Value is set randomly from a predefined String[] in KVPair
			kv.setuserVal(kv.RandValue());
			LList.add(kv);
		}
		} else if(!(HTab == null)) {
			for (int i = 0; i < n; i++) {
				KVpair kv = new KVpair(rs.getAlphaNumericString(Keylength));
				kv.setuserVal(kv.RandValue());
				
				//same logic as above except the put function in a HashTable has different arguments
				//and the actual object isn't inserted into the HashTable, it is temporarily created\
				//then its Key and Value components are placed into the Hashtable
				HTab.put(kv.getKey(), kv.getuserVal());
				
			}
		}
	
	}
	//To get all Keys sorted
	public String[] allKeys(){
        String[] answer = null;
        Enumeration pairs;
        
        if(!(LList == null)) {
        	answer = new String[amtcars];
        	
        	//All linked list keys are transfered into an array
            for(int i = 0; i < LList.size(); i++) {
                answer[i] = LList.get(i).getKey();
            }
            //it is quicksorted for better running time
            quickSort(answer, 0, LList.size()-1);
            
        }else if(!(HTab == null)) {
        	//same logic as linked list except HashTables returns all keys as Enums
        	answer= new String[HTab.size()];
            Enumeration enu = HTab.keys();
            int i = 0;
            
            while(enu.hasMoreElements() && i<HTab.size()) {
                answer[i] = (String) enu.nextElement();
                i++;
            }
            //mergesort is conducted on the bigger set of values that will be contained inside the Hashtable
            mergeSort(answer, 0, HTab.size()-1);
        }

        return answer;
        
    }
	
	//simply adds Key Value pair depending on whether SmartAR is a LinkedList or HashTable
	public void add(String key, String value) {
		KVpair kv = new KVpair(key, value);
		
		if(!(LList == null)) {
			
			LList.add(kv);
			amtcars++;
		}else if(!(HTab == null)) {
		
			HTab.put(kv.getKey(), kv.getuserVal());
			amtcars++;
		}
	}
	
	
	public String remove(String key){
		
		String toremove = "";
		
		if(!(LList == null)) {
			Object[] CopyArr = LList.toArray(); //to access the values from the linkedlist objects, they are first dumped into an Array
			for (Object kv : CopyArr) {
				
				if(((KVpair) kv).getKey().equalsIgnoreCase(key)) {//then a for each loop tests the condition to find the key in the argument
					
					//the value to be removed will be returned
					toremove = ((KVpair) kv).getuserVal();
					//the KVpair is removed 
					LList.remove(kv);
					amtcars--;
				
				}else continue;
			}
		}else if(!(HTab == null)) {
			//much simpler get function takes in the key argument and sets the value to be returned
			toremove = (String) HTab.get(key);
			//The Value is simply removed using the appropriate function
			HTab.remove(key);
			amtcars--;
		}
		
		return toremove;
		
		
	}
	//Values are gotten using respective ADT functions
	public String getValues(String key) {
		String toget = "";
		
		if(!(LList == null)) {
			
			for (KVpair kv : LList) {
				if(kv.getKey().equalsIgnoreCase(key)) {
					toget = kv.getuserVal();
				}else continue;
			}
		}else if(!(HTab == null)){
			toget = (String) HTab.get(key);
		}
		
		return toget;
	}
	
	public String nextKey(String key) {
		String next = "";
		String[] theKeys = this.allKeys();
		
		//if the key that has been past is the very last entry
		if(key.compareToIgnoreCase(theKeys[(theKeys.length-1)]) == 0) {
			next += "Aint nothin at the end of the list there sonny";
			return next;
		}
		
		//if it isn't the for loop searches through the entirety of the sorted Keys 
		for(int i = 0; i < theKeys.length; i++) {
			//once the arg key is found
			if(key.compareToIgnoreCase(theKeys[i]) == 0) {
				//the next key is assigned
				next = theKeys[i+1];
			}
		}
		
		return next;
	}
	
	public String prevKey(String key) {
		String prev = "";
		String[] theKeys = this.allKeys();
		
		//if the argument key is at the beginning of the array
		if(key.compareToIgnoreCase(theKeys[0]) == 0) {
			return "Aint nothin at the start of the list there, sonny";
		}
		
		//if not the key is searched in the sorted Keys String array
		for(int i = 0; i < theKeys.length; i++) {
			//if it is found
			if(key.compareToIgnoreCase(theKeys[i]) == 0) {
				//the key prior to the argument key is assigned and returned
				prev = theKeys[i-1];
			}
		}
		
		return prev;
	}
	
	//A linked list keeps track of previous cars who have the same license plates
	public LinkedList previousCars(String key) {
		String[] sorted = this.allKeys();
		History = new LinkedList<>();
		KVpair toinsert = null;
		
		if(!(LList == null)) {
			//looping through the sorted key array
			for (int i = 0; i < sorted.length; i++) {
			//we try to find the argument key within the array
				if(key.equalsIgnoreCase(sorted[i])) {
					
					//if it is found, it is retrieved from the LinkedList SmartAR
					toinsert = LList.get(i);
					//and inserted into History LL
					History.add(toinsert);
				}
			}
			
		} else if(!(HTab == null)){
			for (int i = 0; i < HTab.size(); i++) {
				//if instead Smart AR is a HashTable we search for the key in the sorted Array
				if(key.equalsIgnoreCase(sorted[i])) {
					
					//a copy of the KVpair located in the Hashtable has itsvalues set to the key that is found
					//and dumped into the History LinkedList
					toinsert = new KVpair(key);
					toinsert.setuserVal((String) HTab.get(key)); 
					History.add(toinsert);
				}
			}
		}
		
		return History;
	}
}
