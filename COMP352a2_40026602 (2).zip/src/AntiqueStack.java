
public class AntiqueStack {
	public static void main(String [] args) {
		double [] Array = new double[10];
		
		Stack1 S = new Stack1();
		
		
		S.push(77.0, Array);
		S.push(3.0, Array);
		S.push(11.5, Array);
		S.push(3.9, Array);
		S.push(101.5, Array);
		S.push(17.8, Array);
		S.push(2.7, Array);
		S.push(1.1, Array);
		S.push(6.1, Array);
		S.push(5.2, Array);
		
		//System.out.println(S.pop(Array));
		for(double d: Array) {
			System.out.println(d);
		}
		//System.out.println(S.size(Array));
	}
}
