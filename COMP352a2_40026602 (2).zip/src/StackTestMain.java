
public class StackTestMain {
	
	public static StackTest<Integer> RemoveDuplicates(int A[]) throws FullStackException {
		StackTest<Integer> temp = new StackTest<>(100);
		StackTest<Integer> answer;
		int count=0;
		int temp2 = 0;
		
		for(int i = 0; i <=(A.length-1); i++) {
			for(int j = 1; j <=(A.length-1); j++) {
				if(A[j-1] > A[j]) {
					temp2 = A[j-1];
					A[j-1] = A[j];
					A[j] = temp2;
				}
			}
		}
		
		for(int i = 0; i < A.length-1; i++) {
			if (A[i] != A[i+1]) {
				count++;
				temp.push(A[i]);
			}if(i == A.length-2) {
				temp.push(A[i+1]);
				count++;
			}
		}
		
		 answer = new StackTest<>(count);
		 
		 for(int i= 0; i < answer.size(); i++) {
			 answer.push(temp.pop());
		 }
		 
		 return answer;
	}
	
	public static void main(String[] args) {
		
		int[] myArr = {100, 8, 9, 7, 3, 8, 100, 100, 6, 9, 8, 7, -101, -100};
		
		try {
			StackTest<Integer> nextGuy = RemoveDuplicates(myArr);
			nextGuy.printString();
		} catch (FullStackException e) {
			
			e.printStackTrace();
		}
		
		
	}

}
