

public class Stack1<E> {
	
	private int t = -1;
	
	public void push(double e, double[] Array){
		double temp = 0;
		if(isFull(Array)) return;
		if(isEmpty(Array)) Array[++t] = e;
		else if(e > Array[t])
			Array[++t] = e;
		else {
			 temp = Array[t];
			  Array[t] = e;
			  Array[++t] = temp;
			  }
		
	}
	
	public double pop(double[] Array){
		double answer = Array[t];
		Array[t] = 0.0;
		t--;
		return answer;
	}
	
	public int size(double[] Array) {
		return(t + 1);
	}
	
	public boolean isEmpty(double[] Array){
		return t == -1;
	}
	
	public boolean isFull(double[] Array) {
		return t == (Array.length - 1);
	}
	
}
