import java.util.EmptyStackException;

public class StackTest<E> {
	
	private int t = -1;
	private E[] Array;
	private final int CAPACITY = 10;
	
	public StackTest() {
		this.Array = (E[]) new Object[CAPACITY];
	}
	
	public StackTest(int capacity) {
		this.Array = (E[]) new Object[capacity];
	}
	
	public void push(E x) throws FullStackException {
		if (isFull())
			throw new FullStackException("Stack is full");
		t += 1;
		Array[t] = x;
	}
	
	public E pop() throws EmptyStackException{
		if(isEmpty())
			throw new EmptyStackException();
		
		E answer = Array[t];
		Array[t] = null;
		t -= 1;
		return answer;
	}
	
	public boolean isFull() {
		return t == (Array.length)-1;
	}
	
	public boolean isEmpty() {
		return t == -1;
	}
	public int size() {
		return Array.length;
	}
	
	public void printString() {
		for(int i = 0; i < Array.length; i++) {
			System.out.print(Array[i] + ", ");
		}
	}
}
/*	public E[] push(E[] Array){
		int count = 0;
		for(int i = 0; i < Array.length; i++) {
			for(int j = 1; j < Array.length; j++) {
				if(Array[i] == Array[j]) {
					Array[j] =  null;
				}else {
					continue;
				}
			}
		}
		for(E i : Array) {
			if(i ==  null) continue;
			else
				count++;
		}
		
		Integer [] MyArr = new Integer[count];
		
		for(E i : Array) {
			if(i == null) continue;
			else
				MyArr[++t] = (Integer) i;
		}
		
		return (E[]) MyArr;
	}
	
	public double pop(double[] Array){
		double answer = Array[t];
		Array[t] = 0.0;
		t--;
		return answer;
	}
	
	public int size(double[] Array) {
		return(t + 1);
	}
	
	public boolean isEmpty(double[] Array){
		return t == -1;
	}
	
	public boolean isFull(double[] Array) {
		return t == (Array.length - 1);
	}
	
}
*/