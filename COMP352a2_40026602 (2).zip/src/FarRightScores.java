import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
public class FarRightScores {
	
	
	public static boolean ScoreFarRight(int pos, int[] squares) throws invalidpositionexception {
		
		if(pos < 0 || pos > squares.length)//if input is invalid
			throw new invalidpositionexception();
		if(squares[pos] == 0) //if we have found the correct answer
		{
			
			return true;
		}
		if((pos + squares[pos] >= squares.length && pos - squares[pos] < 0)) // if the position jumps out of either end of the array
		{
			
			return false;
		}
		if(pos + squares[pos] >= squares.length && squares[pos] == squares[pos-squares[pos]]) //if the position + the array value would go out of bounds
			//and if that value at the position is equal to the value located 
			//at the position minus this CURRENT position
		{
			
			return false;
		}
		if(pos + squares[pos] < squares.length | pos - squares[pos] < 0)//if you can move forward you need to either not go out of bounds on both ends of the array
		{
			return ScoreFarRight(pos + squares[pos], squares);
		}
		if(pos + squares[pos] >= squares.length && pos - squares[pos] >= 0) // to move back you need to be going out of bounds on one end AND when you go backwards you don't go out of bounds
		{
			return ScoreFarRight(pos - squares[pos], squares);
		}
		 return false;
	
		
		
	}
	public static void main(String[] args) {
		File myFile = new File("log.txt");
		PrintWriter pw = null;
		
		int[] Arr0 = {5, 8, 2, 3, 1, 5, 0};
		int[] Arr1 = {8, 2, 3, 1, 5, 0};
		int[] Arr2 = {4, 8, 5, 2, 3, 5, 1, 6 ,4, 0};
		int[] Arr3 = {2, 5 ,7 ,2, 0};
		int[] Arr4 = {5, 8, 2, 100, 101, 12, 13,  0};
		int[] Arr5 = {1, 2, 3, 0};
		int[] Arr6 = {1, 1, 1, 0};
		int[] Arr7 = {1, 5, 6, 7, 9, 1, 2, 3, 2, 5, 6,3 ,4 ,2, 1, 0};
		int[] Arr8 = {5, 0};
		int[] Arr9 = {0};
		int[] Arr10 = {7, 4, 2, 3, 2, 3, 1, 1, 5, 3 ,2 , 1, 0};
		int[] Arr11 = {7, 6, 4, 3, 2, 0};
		int[] Arr12 = {3, 4, 2, 5, 3, 2, 2, 1, 4, 5, 6, 7, 0};
		int[] Arr13 = {1,2,1,1,2,3,4,1,1,1,3,4, 2, 1, 0};
		int[] Arr14 = {2,3,1,0};
		int[] Arr15 = {5, 8, 2, 3, 1, 5, 0};
		int[] Arr16 = {11,8,8,1,2,4,5,6,7,8,3,2,2,1,1,2,34,8,5,3, 0};
		int[] Arr17 = {6, 4, 3,8,6, 7,8, 7,6,4,3,5,0};
		int[] Arr18 = {7,4,6,1,2, 0};
		int[] Arr19 = {5, 7,4 ,4,2,6, 0};
		
		try {
			
			pw = new PrintWriter(myFile);
			
			 pw.println("Whether the First game is solveable: " + ScoreFarRight(0, Arr0));
			 pw.println("Whether the Second game is solveable: "+ ScoreFarRight(1, Arr1));
			 pw.println("Whether the Third game is solveable: "+ ScoreFarRight(3, Arr2));
			 pw.println("Whether the Fourth game is solveable: "+ ScoreFarRight(2, Arr3));
			 pw.println("Whether the Fifth game is solveable: "+  ScoreFarRight(3, Arr4));
			 pw.println("Whether the Sixth game is solveable: "+  ScoreFarRight(0, Arr5));
			 pw.println( "Whether the Seventh game is solveable: "+ ScoreFarRight(0, Arr6));
			 pw.println( "Whether the Eighth game is solveable: " +ScoreFarRight(6, Arr7));
			 pw.println("Whether the Ninth game is solveable: "  +ScoreFarRight(0, Arr8));
			 pw.println( "Whether the Tenth game is solveable: " +ScoreFarRight(0, Arr9));
			 pw.println( "Whether the Eleventh game is solveable: " +ScoreFarRight(10, Arr10));
			 pw.println("Whether the Twelvth game is solveable: "  +ScoreFarRight(2, Arr11));
			 pw.println("Whether the Thirteenth game is solveable: "  +ScoreFarRight(5, Arr12));
			 pw.println("Whether the Fourteenth game is solveable: "  +ScoreFarRight(0, Arr13));
			 pw.println("Whether the Fifteenth game is solveable: " +ScoreFarRight(0, Arr14));
			 pw.println("Whether the Sixteenth game is solveable: "  +ScoreFarRight(3, Arr15));
			 pw.println("Whether the Seventeenth game is solveable: "  +ScoreFarRight(0, Arr16));
			 pw.println("Whether the Eighteenth game is solveable: "  +ScoreFarRight(7, Arr17));
			 pw.println("Whether the Nineteenth game is solveable: "  +ScoreFarRight(0, Arr18));
			 pw.println("Whether the Twentith game is solveable: " +ScoreFarRight(3, Arr19));
			 
			 pw.close();
		} catch (invalidpositionexception e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}

}