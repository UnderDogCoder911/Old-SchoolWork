
public class invalidpositionexception extends Exception {

}
