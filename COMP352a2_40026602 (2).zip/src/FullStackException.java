
public class FullStackException extends Exception {

	public FullStackException(String msg) {
		super(msg);
	}

}
