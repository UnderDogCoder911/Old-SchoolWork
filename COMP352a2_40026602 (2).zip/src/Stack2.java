

public class Stack2<E> {

	private int t = -1;
	
	public void push(E e, E[] Array){
		
		
		
		if(!(Array[t].getClass() == (null)))
		
		Array[++t] = e;
		
	}
	
	public E pop(E[] Array){
		E answer = Array[t];
		Array[t] = null;
		t--;
		return answer;
	}
	
	public int size(E[] Array) {
		return(t + 1);
	}
	
	public boolean isEmpty(E[] Array){
		return t == -1;
	}
	
	public boolean isFull(E[] Array) {
		return t == (Array.length - 1);
	}
	
}



