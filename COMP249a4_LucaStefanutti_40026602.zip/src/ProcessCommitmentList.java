/**
 * Luca Stefanutti ID 40026602
 * COMP249
 * Assignment 4
 * Due Date August 11 2019
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ProcessCommitmentList {

	/*
	 * Assignment 4
	 * Question: IV
	 * Written by Luca Stefanutti
	 */
	public static void main(String[] args) {

		Scanner kb = new Scanner(System.in);
		ActivityList ActList1 = new ActivityList();
		ActivityList ActList2 = new ActivityList();

		File MSchedule = new File("MSchedule.txt");

		Scanner FileReader = null;
		Scanner FileReader2 = null;

		try {
			//Initialize File Reader with the MSchedule.txt
			FileReader = new Scanner(new FileInputStream(MSchedule));
			int count = 0;
			
			//loops through the File reader
			while (FileReader.hasNextLine()) {
				//stores all the relevant data into String 
				String ActID = FileReader.next();
				String ActName = FileReader.next();
				FileReader.nextLine();
				String StartTime = FileReader.nextLine();
				String EndTime = FileReader.nextLine();
				
				//changes the strings into doubles
				StartTime = StartTime.substring(2);
				EndTime = EndTime.substring(2);

				double TrueStartTime = Double.parseDouble(StartTime);
				double TrueEndTime = Double.parseDouble(EndTime);

				//creates activity objects
				Activity someAct = new Activity(ActID, ActName, TrueStartTime, TrueEndTime);
				
				//adds the objects to the start of the linked list
				ActList1.addToStart(someAct);
				count++;
				
				//prints out the linked list
				System.out.println(ActList1.find(someAct.getActivityID()).getAnActivity().toString());

			}
			//attempts to remove dual occurances of HH101
			ActList1.find("HH101");
			ActList1.deleteFromStart();
			FileReader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		//ArrayList initialized which will hold the activity objects read in from the file
		ArrayList<Activity> ActArrList = new ArrayList<Activity>(10);

		//prompts the user to input a file
		System.out.print("Please enter input file: ");
		String userfile = kb.next();
		File userFile = new File(userfile);

		try {
			
			FileReader = new Scanner(new FileInputStream(userFile));
			//loops through the File, skips over strings that are not activity ID 
			while (FileReader.hasNextLine()) {

				String SomeAct = FileReader.nextLine();
				if (SomeAct.equals("Current") || SomeAct.equals("New")) {
					continue;
				} else {
					//if they are not skipped over then the ID is used to create a new Activity
					//using the copy constructor, the Activity is obtained from the linked list
					ActArrList.add(new Activity(ActList1.find(SomeAct).getAnActivity(), SomeAct));
				}
			}
			//prints out the Array list
			System.out.println("\n" + ActArrList.toString());

			//loops through the ArrayList with activity objects
			for (int i = 0; i < ActArrList.size(); i++) {
				
				//if the object is found in the Activity linked list
				if (ActList1.contains(ActArrList.get(i).getActivityID())) {

					//then the isOnsameTime method invoke, if both start times and end times are the same
					if (ActArrList.get(i).isOnSameTime(ActList1.find(ActArrList.get(i).getActivityID()).getAnActivity())
							.equals("Same time")) {
						//prints out the relevant answer
						System.out.println("User can't commit to " + ActArrList.get(i).getActivityID()
								+ " as he/she is not finished with his/her prior commitment.");
					//if both have different times
					} else if (ActArrList.get(i)
							.isOnSameTime(ActList1.find(ActArrList.get(i).getActivityID()).getAnActivity())
							.equals("Different time")) {
						//prints out the relevant answer
						System.out.println("User can commit to " + ActArrList.get(i).getActivityID()
								+ " as he/she is free during that time.");
					//if they have some overlap
					} else if (ActArrList.get(i)
							.isOnSameTime(ActList1.find(ActArrList.get(i).getActivityID()).getAnActivity())
							.equals("Some Overlap")) {
						
						//prints out the relevant answer
						System.out.println("User can't commit to " + ActArrList.get(i).getActivityID()
								+ " as he/she has another commitment at the exact same time.");

					}

				}
			}

			FileReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		//prompt the user to input an activity ID
		System.out.println("Please enter an activityID, enter no to stop");
		kb.nextLine();
		String ActID1 = kb.nextLine();

		//while the user has not inputed no, 
		while (!ActID1.equalsIgnoreCase("no")) {
			//the find() method is invoked using the user input
			ActList1.find(ActID1);
			//askes again the user again for a new Activity ID
			System.out.println("Please enter an activityID, enter no to stop");
			ActID1 = kb.nextLine();
		}

		//creates various Activity objects to be tested
		Activity Act1 = new Activity("GP102", "GradPrixRacing", 8.0, 13.0);
		Activity Act2 = new Activity("TF103", "Team Formation", 10.25, 18.30);
		
		//tests copy constructor and clone
		Activity Act3 = new Activity(Act1, "GP102");
		Activity Act4 =  Act2.clone("TF103");
		Activity Act5 = new Activity("RP101", "RolePlaying class", 9.0, 12.0);
		
		//inserts an object at a given index
		ActList1.insertAtIndex(Act5, 3);
		
		//if it is inserted prints out the relevant string
		if(ActList1.contains("RP101")) {
			System.out.println("The Activity insertion was successful");
		}else {
			System.out.println("The Activity insertion was NOT successful");
		}
		
		//tests out the equal method and see if the copy constructor works
		if(Act1.equals(Act3)) {
			System.out.println("The copy constructor was successful");
		}else {
			System.out.println("The copy constructor was UNsuccessful");
		}
		
		//sees if clone method worked
		if(Act2.equals(Act4)) {
			System.out.println("The clone method was successful");
		}else {
			System.out.println("The clone method was UNsuccessful");
		}

		//testing out the copy constructor for a linked list DOES NOT WORK
		ActList2 = new ActivityList(ActList1);

		//tests equals for linked lists that has been coded in the ActivityList class
		if (ActList1.equals(ActList2)) {
			System.out.println("The ArrayLists are equal.");
		} else {
			System.out.println("The ArrayLists are NOT equal.");
		}

		//more testing of inserting at index as well as the throwed exception
		// ActList1.insertAtIndex(Act1, 11);
		ActList1.insertAtIndex(Act1, 8);
		ActList1.insertAtIndex(Act2, 3);

		//seeing if the objects got inserted IT DOESNT ALWAYS WORK
		ActList1.find("GP102");
		ActList1.find("TF103");

		//delete from index test
		ActList1.deleteFromIndex(8);
		ActList1.deleteFromIndex(3);

		//if the objects are no longer in the linked list then the delete works, else it doesn't
		//also tests contains method
		if (ActList1.contains("GP102")) {
			System.out.println("The List does contain the Activity Object we added");
		} else {
			System.out.println("The List does NOT contain the Activity Object we added");
		}

		
		if (ActList1.contains("TF103")) {
			System.out.println("The List does contain the second Activity Object we added");
		} else {
			System.out.println("The List does NOT contain the second Activity Object we added");
		}
		
		ActList1.find("HH101");
		ActList2.find("HH101");
		
		//testing out the deletefromstart method
		//DOESNT WORK BECAUSE BOTH WERE NOT PROPERLY COPIED
		ActList1.deleteFromStart();
		ActList2.deleteFromStart();
		ActList2.deleteFromStart();
		
		//if HH101 is no longer there then the deletes from start work else if it still exits it didnt work
		if(ActList1.contains("HH101")) {
			System.out.println("The delete from start did NOT work");
		}else {
			System.out.println("The delete from start did work");
		}
		
		if(ActList2.contains("HH101")) {	
		System.out.println("The delete from start did NOT work");
		}else {
		System.out.println("The delete from start did work");
	}
	}

}
