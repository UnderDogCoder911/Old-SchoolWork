/**
 * 
 * @author Luca Stefanutti ID 40026602
 * COMP249
 * Assignment 4
 * Due Date August 11 2019
 *
 */
public class Activity implements Commitable {
	
	/*
	 * Assignment 4
	 * Question: II
	 * Written by: Luca Stefanutti
	 */
	private String activityID;
	private String activityName;
	private double startTime;
	private double endTime;
	
	/**
	 * Parameterized constructor
	 * @param activityID an activity ID
	 * @param activityName the name of an activity 
	 * @param startTime the start time of a given activity
	 * @param endTime the end time of a given activity
	 */
	public Activity(String activityID, String activityName, double startTime, double endTime) {
		this.activityID = activityID;
		this.activityName = activityName;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	/**
	 * copy constructor
	 * @param someAct takes another activity object
	 * @param activityID as well as the same ID of the copied activity
	 */
	public Activity(Activity someAct, String activityID) {
		this.activityID = activityID;
		activityName = someAct.getActivityName();
		startTime = someAct.getStartTime();
		endTime = someAct.getEndTime();
	}
	
	/**
	 * Custom clone method, not overloaded
	 * @param activityID takes in the ID of a given activity
	 * @return returns a new activity object by invoking the parameterized constructor
	 */
	public Activity clone(String activityID) {
		 Activity cloneAct = new Activity(activityID, activityName, startTime, endTime); 
		 return cloneAct;
	}
	
	public String getActivityID() {
		return activityID;
	}
	public void setActivityID(String activityID) {
		this.activityID = activityID;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public double getStartTime() {
		return startTime;
	}
	public void setStartTime(double startTime) {
		this.startTime = startTime;
	}
	public double getEndTime() {
		return endTime;
	}
	public void setEndTime(double endTime) {
		this.endTime = endTime;
	}

	/**
	 * overriden equals method
	 * @return returns true in an activity has the same name, start time and end time, false otherwise
	 */
	public boolean equals(Object arg0) {
		
		if(arg0 == null && !(arg0 instanceof Activity)) {
			return false;
		}else {
			Activity someAct = (Activity)arg0; 
			return (activityName.equalsIgnoreCase(someAct.getActivityName()) && startTime == someAct.getStartTime() 
					&& endTime == someAct.getEndTime());
		}
	}

	/**
	 * overriden toString method
	 * @return returns a string of an activity object with the relevant information
	 */
	public String toString() {
		return "ActivityID: "+ this.getActivityID()
				+"\nActivityName: "+this.getActivityName()
				+"\nStartTime: "+this.getStartTime()
				+"\nEndTime: "+this.getEndTime();
	}
	
	/**
	 * a comparing method that is implmented from the Commitable interface
	 * @return returns a string depending on when an activity starts and ends, "Same time" if they have similar start and end times
	 * 			"Different time" if the start and end times differ, and "Some Overlap" if either the start times are the same but different end times
	 * 			or start times are different but end times same
	 */
	public String isOnSameTime(Activity S) {
		String str = "";
		
		if(this.getStartTime() == S.getStartTime() && this.getEndTime() == S.getEndTime()) {
			str += "Same time";
		
		}else if(this.getStartTime() != S.getStartTime() && this.getEndTime() != S.getEndTime()) {
			str += "Different time";
		
		}else if((this.getStartTime() == S.getStartTime() && this.getEndTime() != S.getEndTime()) ||
				(this.getStartTime() != S.getStartTime() && this.getEndTime() == S.getEndTime())) {
			str += "Some Overlap";
		}
		
		return str;
		
	}
}
