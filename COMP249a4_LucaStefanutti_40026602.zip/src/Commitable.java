/**
 * 
 * @author Luca Stefanutti ID 40026602
 *COMP249
 *Assignment 4
 *Due Date August 11 2019
 */
public interface Commitable {
	
	/*
	 * Assignment 4
	 * Question: I
	 * Written: by Luca Stefanutti
	 */
	public String isOnSameTime(Activity S);

}
