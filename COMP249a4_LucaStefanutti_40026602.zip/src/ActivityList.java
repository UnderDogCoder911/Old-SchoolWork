/**
 * @author Luca Stefanutti ID 40026602
 * COMP249
 * Assignment 4
 * Due Date August 11 2019
 */
import java.util.NoSuchElementException;

public class ActivityList {
	/*
	 * Assignment 4
	 * Question: III
	 * Written by Luca Stefanutti and Walter Savitch
	 */
	public class ActivityNode{
		private Activity anActivity;
		private ActivityNode anActivityNode;
		
		/**
		 * Default constructor for a ActivityNode
		 */
		public ActivityNode() {
			anActivity = null;
			anActivityNode = null;
		}
		/**
		 * parameterized constructor for an ActivityNode
		 * @param someAct takes in an Activity object
		 * @param someActNode and a link to another ActivityNode
		 */
		public ActivityNode(Activity someAct, ActivityNode someActNode) {
			anActivity = someAct;
			anActivityNode = someActNode;
		}
		/**
		 * copy constructor for the ActivityNode inner class
		 * @param someActNode takes in another activity node and copies the relevant attributes
		 */
		public ActivityNode(ActivityNode someActNode) {
			anActivity = someActNode.getAnActivity();
			anActivityNode = someActNode.getAnActivityNode();
		}
		
		/**
		 * clone method for the ActivityNode inner class
		 * @return an activitynode created using the copy constructor
		 */
		public ActivityNode clone() {
			return new ActivityNode(this);
		}

		public Activity getAnActivity() {
			return anActivity;
		}

		public void setAnActivity(Activity anActivity) {
			this.anActivity = anActivity;
		}

		public ActivityNode getAnActivityNode() {
			return anActivityNode;
		}

		public void setAnActivityNode(ActivityNode anActivityNode) {
			this.anActivityNode = anActivityNode;
		}
		
	}
	
	private ActivityNode head;
	
	private int size;
	
	/**
	 * default constructor for an activity list
	 */
	public ActivityList() {
		
		head = null;
		size = 0;
	}
	
	/**
	 * Copy constructor for an activty list
	 * @param someAList takes another list and makes a deep copy of it
	 */
	public ActivityList(ActivityList someAList) {
		if (someAList == null) {
			throw new NullPointerException();
		}
		if(someAList.head == null) {
			head = null;
		}else {
			head = copyOf(someAList.head);
			
		}
	}
	
	/**
	 * method to attempt to make a deep copy of the link lists, by copying the end node of position and linking it to the end of the copy linked list 
	 * @param someList takes in another linked list to be cloned
	 * @return returns a new head node of the copied link list to be itrated over
	 */
	private ActivityNode copyOf(ActivityNode someList) {
		ActivityNode position = someList;
		ActivityNode newH;
		ActivityNode end = null;
		
		newH = new ActivityNode((Activity)(position.anActivity).clone(position.getAnActivity().getActivityID()), null);
		end = newH;
		position = position.anActivityNode;
		
		while(position != null) {
			end.anActivityNode = new ActivityNode((Activity)(position.anActivity).clone(position.getAnActivity().getActivityID()), null);
			end = end.anActivityNode;
			position = position.anActivityNode;
		}
		
		return newH;
	}
	/**
	 * Adds an activity node to the start of a linked list
	 * @param someAct takes in some Activity object to become the head node
	 */
	
	public void addToStart(Activity someAct) {
		head = new ActivityNode(someAct, head);
		size++;
	}
	/**
	 * Attempts to insert a node in between a position node and a next node in a linked list
	 * this is done by making the position node link point to the new activity node
	 * and making the new activity node point to next
	 * **DOES NOT SEEM TO WORK**
	 * @param someAct the activity node to be inserted
	 * @param index the index of the list to be added at
	 * @throws NoSuchElementException can throw a no such element exception if someone enters an index bigger/smaller than the size of the linked list
	 */
	
	public void insertAtIndex(Activity someAct, int index) throws NoSuchElementException{
		
		
		if (index < 0 || index > size) {
			throw new NoSuchElementException();
		}else{
			
			ActivityNode position = head;
			ActivityNode next = null;
			int count = 0;
			
			while(position != null && count <= size-1) {
			
			if (index == 0) {
				ActivityNode AddedNode = new ActivityNode(someAct, null);
				head = AddedNode;
				AddedNode.anActivityNode = position;
				size++;
				
			}else if(count == index) {
					ActivityNode AddedNode = new ActivityNode(someAct, position);
					next.anActivityNode = AddedNode;
					size++;
					
				}
				next = position;
				position = position.anActivityNode;
				count++;
			}
			
		}
	}
		
	
	
	/**
	 * Deletes an Activity node by breaking the links of both position and next to the indexed node
	 * Both position and next thus point to the node after the node we wish to remove. 
	 * **DOES NOT SEEM TO WORK**
	 * @param index the inputed index, being the node which will be deleted
	 * @throws NoSuchElementException if the index is smaller or bigger than the size of the linked list will throw this exception
	 */
	public void deleteFromIndex(int index) throws NoSuchElementException{
		
		if (index < 0 || index > size) {
			throw new NoSuchElementException();
		}else {
			ActivityNode position = head;
			ActivityNode next = null;
			int count = 0;
			
			if (index == 0) {
				head = head.anActivityNode;
				size--;
			}else {
				while(position != null && count <= size-1) {
					if (count == index) {
						next.anActivityNode = position.anActivityNode;
						position = position.anActivityNode;
						size--;
					}
				
					next = position;
					position = position.anActivityNode;
					count++;
				}
			}
}
}
	
	/**
	 * Method to delete node from the start by making the head node point to the next node
	 */
	public void deleteFromStart() {
		
		if (head != null && size > 0) {
			head = head.anActivityNode;
			size--;
		}
	}
	
	/**
	 * Replaces an activity object at a given node in the linked list
	 * @param someAct the activity object to be inserted
	 * @param index the index at which the object must be inserted
	 */
	public void replaceAtIndex(Activity someAct, int index) {
		if (index < 0 || index > size) {
			return;
		} else {
			ActivityNode position = head;
			int count = 0;
			
			if (index == 0) {
				head.setAnActivity(someAct);
			}else {
				while(position != null && count <= size-1) {
					if(count == index) {
						position.setAnActivity(someAct);
					}	
					position = position.anActivityNode;
					count++;
				}
			}
			
		}
	}
	
	/**
	 * Method to find an Activity in the linked list through
	 * searching for the Activity ID
	 * @param ActID the activity ID to be searched
	 * @return returns the node which contains the activity as well as a print statement to
	 * 			know where the node was located
	 */
	public ActivityNode find(String ActID) {
		
		int count = 0;
		ActivityNode position = head;
		count++;
		
		while(position != null) {
			if (ActID.equals(position.anActivity.getActivityID())) {
				System.out.print("\nthe count to find the node is " + count +"\n");
				return position;
			}
			position = position.anActivityNode;
			count++;
		}
		System.out.print("\nthe count to NOT find the node is " + count);
		return null;
	}
	
	/**
	 * Using the Activity ID, returns a boolean value depending on 
	 * weather or not a linklist contains the activity
	 * @param ActID takes in a activity ID to be searched
	 * @return returns true if the activity at a given node has the same ID as the parameter, false otherwise
	 */
	public boolean contains(String ActID) {
		
		ActivityNode position = head;

		while(position != null) {
			if (ActID.equals(position.anActivity.getActivityID())) {
				return true;
			}
			position = position.anActivityNode;
			
		}
		return false;
	}
	/**
	 * equals method that loops through both lists and if there is an activity 
	 * object that is not equal to the other then returns false
	 * else returns true
	 * @param someList takes in another linked list
	 * @return true if there are no two activites that are unequal, false otherwise
	 */
	public boolean equals(ActivityList someList) {
		
		if(this.size != someList.size) {
			return false;
		}
		
		ActivityNode position = head;
		ActivityNode otherposition = someList.head;
		
		while (position != null) {
			if (!(position.anActivity.equals(otherposition.anActivity))) {
				return false;
			}
			position = position.anActivityNode;
			otherposition = otherposition.anActivityNode;
		}
		return true;
		
	}
}
