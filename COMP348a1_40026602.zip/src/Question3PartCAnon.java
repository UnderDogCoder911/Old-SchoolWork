
public class Question3PartCAnon {

	public static void main(String[] args) {
		Thread p = new Thread() {
			
			public void run() {
				for (int i = 1; i < 101; i++) {
					System.out.println(i);
				}
			}
		};
		
		p.start();
		new Thread(p).start();

	}

}
