
public interface Interface3 {
	boolean somefunction2(int i, String s);
}
