
public class Math101 {
	
	public static interface Callback<T>{
		void process(T notification);
	}
	
	public static void Divide(int a, int b, Callback<Integer> onSuccess,
			Callback<String> onError) {
		try {
			int result = a/b;
			onSuccess.process(result);
		}
		catch(Exception e) {
			onError.process(e.getMessage());
		}
		
		
	}
	
	public static void main(String[] args) {
		Callback<Integer> onSuccess = (Integer notification) -> { 
				System.out.println("The result of a/b is " + notification);
			};
		
			Callback<String> onError = (String notification) -> {
				System.out.print("Error occurred: " + notification);
			};
		
			Divide(1, 2, onSuccess, onError);
			Divide(3, 0, onSuccess, onError);
	}
}
