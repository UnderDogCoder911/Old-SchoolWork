
public class Question3PartA implements Runnable {

	public void run() {
		for (int i = 1; i < 101; i++) {
			System.out.println(i);
		}
	}
	
	public static void main(String[] args) {
		Question3PartA counting = new Question3PartA();
		Question3PartA counting1 = new Question3PartA();
		counting.run();
		counting1.run();
		System.out.println("THE END");

	}

	

}
