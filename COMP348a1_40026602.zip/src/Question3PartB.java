
public class Question3PartB implements Runnable {

	public void run() {
		for (int i = 1; i < 101; i++) {
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		Question3PartA counting1 = new Question3PartA();
		Question3PartA counting2 = new Question3PartA();
		
		new Thread(counting1).start();
		new Thread(counting2).start();
		
		//threads are executed simultaneously so the counting 1 to 100
		//does not occur in 2 separate instances e.g. 1-100 then another 
		//print of 1-100. Instead seemingly at random, there will be
		//1 to n integers printed at which point after n, the second thread
		//starts to count after n, so once again it will be 1 to n but this time 
		//it is counting2 not counting1 printing. Similar breaks in 
		//printing occur at various intervals until both have printed up to 100.
	}

}
