
public class Question3PartDLambda {

	public static void main(String[] args) {
		Runnable p = () -> {
			for (int i = 1; i < 101; i++) {
				System.out.println(i);
			}
	};
	
	p.run();
	System.out.println("THE END");

	}

}
