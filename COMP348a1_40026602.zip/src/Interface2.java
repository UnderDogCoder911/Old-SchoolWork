
public interface Interface2 {
	String somefunction1(double a);
}
