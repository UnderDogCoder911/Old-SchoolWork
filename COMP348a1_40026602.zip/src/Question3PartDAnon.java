
public class Question3PartDAnon {

	public static void main(String[] args) {
		
		Runnable r = new Runnable() {
			public void run() {
				for (int i = 1; i < 101; i++) {
					System.out.println(i);
				}
			}
		};
		
		r.run();
		System.out.println("THE END");
	}

}
