
public interface Interface1 {
	 double somefunction();
}

