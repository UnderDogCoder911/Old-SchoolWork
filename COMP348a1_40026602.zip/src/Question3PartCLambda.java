
public class Question3PartCLambda {

	public static void main(String[] args) {
		
		Runnable p = () -> {
			
				for (int i = 1; i < 101; i++) {
					System.out.println(i);
				}

		};
		Thread a = new Thread (p);
		Thread b = new Thread (p);
		a.start();
		b.start();

	}
}
