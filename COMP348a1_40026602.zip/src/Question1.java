
public class Question1 {

	public static void main(String[] args) {
		
		Interface1 somefunction = () -> 5.5;
		
		Interface2 somefunction1 = (a) -> String.format("The number is %d", a);

		Interface3 somefunction2 = (i , s) -> i == Integer.parseInt(s);
	}

}
