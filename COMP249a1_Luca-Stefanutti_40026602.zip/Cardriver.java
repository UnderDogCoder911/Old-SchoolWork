/**
 * Luca Stefanutti ID:40026602
 * COMP249
 * Assignment #1
 * July 17 2019
 */
/*
 * Assignment 1
 * Part 2
 * Luca Stefanutti 40026602
 */
import java.util.Scanner;

public class Cardriver {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		//The Password in order to access the options which require one
		final String PASSWORD = "comp249S19";
		
		System.out.println("Welcome! Thank you for using the Car inventory program");
		
		//prompting the user for the size of the Car object array
		System.out.print("Please enter the maximum number of cars your company can handle: ");
		int size = kb.nextInt();
		
		//with the prompt an array which will later be used is initalized
		Car [] carDatabase = new Car [size];
		
		//The main menu
		System.out.print("What do you want to do?"+"\n"
				+ "1. Enter a new Car to the inventory (password required)"+"\n"
				+ "2. Change information of an existing Car (password required)"+"\n"
				+ "3. Display all the Cars with specific make and model"+ "\n"
				+ "4. Display all the Cars with the given price range"+"\n"
				+ "5. Quit \n"
				+ "Please enter your choice> ");
		
		int prompt = kb.nextInt();
		
		//These counts will be used for the multiple attempts by the user
		//to enter the password
		int count = 1;
		
		int count2 = 1;
		
		//the while loop is used in order to continuously run the program
		//based on the option(represented by int prompt) the user entered
		while (prompt >= 1 && prompt <= 5) {
			
			//option 1
			if (prompt == 1) {
				
				
				System.out.print("Please enter the password: ");
				
				String pwprompt = kb.next();
				
				//If the password is correct
				if(pwprompt.compareTo(PASSWORD) == 0) {
					
					System.out.print("How many cars do you want to enter? ");
					int numCars = kb.nextInt();
					
					//if the number of cars declared is smaller than the number of indexes in the array
					//and it is not a negative amount of cars 
					if(numCars <= carDatabase.length && numCars > 0) {
						
						//the for loop prompts the user for the relevant information
						//to create an object of type Car and stores it into
						//the array created at the start of the driver
						for (int i = 0; i <= numCars-1; i++) {
							
							System.out.print("Please enter the make: ");
							String input_make = kb.next();
							
							System.out.print("Please enter the model: ");
							String input_model = kb.next();
							
							System.out.print("Please enter the year: ");
							int input_year = kb.nextInt();
							
							System.out.print("Please enter the price: ");
							int input_price = kb.nextInt();
							
							Car newCar = new Car(input_make, input_model, input_year, input_price);
							
							carDatabase[i] = newCar;
							
							
						}
						
						//redisplating the main menu after having entered the number of cars
						System.out.print("\nWhat do you want to do?"+"\n"
								+ "1. Enter a new Car to the inventory (password required)"+"\n"
								+ "2. Change information of an existing Car (password required)"+"\n"
								+ "3. Display all the Cars with specific make and model"+ "\n"
								+ "4. Display all the Cars with the given price range"+"\n"
								+ "5. Quit \n"
								+ "Please enter your choice> ");
						
						 prompt = kb.nextInt();
						
					//if the number of cars inputed is greater or less than the total indexes in the array
					}else if(numCars > carDatabase.length || numCars < 0) {
						
						//a message saying the program will only create objects
						//equal to the size of the array
						System.out.print("You can only add the number of remaining places in the array"
								+ " which is: " + carDatabase.length + "\n");
						
						//same for loop as before
						for (int i = 0; i < carDatabase.length; i++) {
							
							System.out.print("Please enter the make: " );
							String input_make = kb.next();
							
							System.out.print("Please enter the model: ");
							String input_model = kb.next();
							
							System.out.print("Please enter the year: ");
							int input_year = kb.nextInt();
							
							System.out.print("Please enter the price: ");
							int input_price = kb.nextInt();
							
							Car newCar = new Car(input_make, input_model, input_year, input_price);
							
							carDatabase[i] = newCar;
							
							
					}
						//redisplaying the main menu
						System.out.print("\nWhat do you want to do?"+"\n"
								+ "1. Enter a new Car to the inventory (password required)"+"\n"
								+ "2. Change information of an existing Car (password required)"+"\n"
								+ "3. Display all the Cars with specific make and model"+ "\n"
								+ "4. Display all the Cars with the given price range"+"\n"
								+ "5. Quit \n"
								+ "Please enter your choice> ");
						
						prompt = kb.nextInt();	
					
					}
					
				//if the password is incorrect when it is not the 3rd, 6th, 9th or 12th try
				}else if(pwprompt.compareTo(PASSWORD) != 0 && (count != 3 && count != 6 && count != 9 && count != 12)) {
					
					System.out.print("Please try again!\n");
					//count keeps track of the attempts to enter the password
					count++;
				
				//if the password is wrong and it is on the 3rd, 6th or 9th try but it isn't the 12th attempt
				}else if(pwprompt.compareTo(PASSWORD) != 0 && (count == 3 || count == 6 || count == 9)) {
					
					//redisplay Main menu
					System.out.print("\nWhat do you want to do?"+"\n"
							+ "1. Enter a new Car to the inventory (password required)"+"\n"
							+ "2. Change information of an existing Car (password required)"+"\n"
							+ "3. Display all the Cars with specific make and model"+ "\n"
							+ "4. Display all the Cars with the given price range"+"\n"
							+ "5. Quit \n"
							+ "Please enter your choice> ");
					
					 prompt = kb.nextInt();
					 
					 //keep track of attempts
					 count++;
					
				//When it is the 12th incorrect password attempt
				}else if(pwprompt.compareTo(PASSWORD) != 0 && count == 12) {
					
					//print message and exit the program
					System.out.print("Program detected suspicious activity and is terminating!");
					System.exit(0);
				}
				
			//option 2
			}else if (prompt == 2) {
				
				System.out.print("Please enter the password: ");
				
				 String pwprompt = kb.next();
				
				//if the password is correct
				if(pwprompt.compareTo(PASSWORD) == 0) {
					
					System.out.print("Which Car do you wish to update?");
					
					int carIndex = kb.nextInt();
					
					boolean index_ok = false;
					
					//the while loop here is to make sure that the user
					//enters a proper index in the carDatabase array
					while(index_ok == false){
					
					//If the index entered is wrong i.e. bigger value than length or a negative value
					if (carIndex >= carDatabase.length || carIndex < 0) {
						
						//prompt the user for a new choice
						System.out.print("Do you wish to:\n"
								+ "1. Re-enter another index?\n"
								+ "2. Quit to main menu?"
								+ "Please enter choice> ");
						
						int mistake_Choice = kb.nextInt();
						
						//if the choice is 1 then the user enters a new index
						//and loops back to check if it is valid
						switch(mistake_Choice) {
						
						case 1: System.out.print("Which Car do you wish to update?");
						
								carIndex = kb.nextInt(); break;
						
						//any other value inputed by the user exits to the main menu
						default: System.out.print("\nWhat do you want to do?"+"\n"
								+ "1. Enter a new Car to the inventory (password required)"+"\n"
								+ "2. Change information of an existing Car (password required)"+"\n"
								+ "3. Display all the Cars with specific make and model"+ "\n"
								+ "4. Display all the Cars with the given price range"+"\n"
								+ "5. Quit \n"
								+ "Please enter your choice> ");
						
						 prompt = kb.nextInt(); index_ok = true; break;
						}
					//if the car index inputed by the user does satisfy the length 
					//of the array
					}else if (carIndex < carDatabase.length) {
						
						index_ok = true;
						
						boolean secondLoop = true;
						//this while loop allows the user to modify a given car make, model
						//year and price until satisfied
						while (secondLoop == true) {
						
						//the relevant information is printed using the Overriden toString()
						System.out.println(carDatabase[carIndex].toString());
						
						//Sub menu giving the choices for the user
						System.out.println("\nWhat information would you like to change? \n"
								+ "1. Car make \n"
								+ "2. Car model \n"
								+ "3. Car year \n"
								+ "4. Car price \n"
								+ "5. Quit \n"
								+ "Please enter your choice> ");
						
						int change_input = kb.nextInt();
						kb.nextLine();
						
						//depending on what the user enters as number
						//he will envoke the given setter for the variable
						//and change it in the object (which is found at the
						//desired index in the object array)
						switch(change_input) {
					
						case 1: System.out.print("Please enter a make: ");
								String make_input = kb.nextLine();
								carDatabase[carIndex].setMake(make_input);
								break;
						
						case 2: System.out.print("Please enter a model: ");
								String model_input = kb.nextLine();
								carDatabase[carIndex].setModel(model_input);
								break;
								
						case 3: System.out.print("Please enter a year: ");
								int year_input = kb.nextInt();
								carDatabase[carIndex].setYear(year_input);
								break;
						
						case 4: System.out.print("Please enter a price: ");
								int price_input = kb.nextInt();
								carDatabase[carIndex].setPrice(price_input);
								break;
						//entering 5 brings back the Main menu and prompts the user for another option
						case 5: System.out.print("\nWhat do you want to do?"+"\n"
								+ "1. Enter a new Car to the inventory (password required)"+"\n"
								+ "2. Change information of an existing Car (password required)"+"\n"
								+ "3. Display all the Cars with specific make and model"+ "\n"
								+ "4. Display all the Cars with the given price range"+"\n"
								+ "5. Quit \n"
								+ "Please enter your choice> ");
								
								prompt = kb.nextInt(); secondLoop = false; break;
						//any other value entered not shown in the sub menu returns a warning message
						default: System.out.print("Please enter an integer value between 1 to 5" ); break;
						}
						}
					}
					}
				//if the password is incorrect but it is not the 3rd attempt
				}else if(pwprompt.compareTo(PASSWORD) != 0 && count2 < 3){
					
					System.out.print("Please try again!\n");
					//this seperate count, keeps track of the password attempts
					//for the 2nd option
					count2++;
					
				//if the password is incorrect and it is the 3rd attempt
				}else if(pwprompt.compareTo(PASSWORD) != 0 && count2 == 3) {
					
					//the Main menu is redisplated
					System.out.print("\nWhat do you want to do?"+"\n"
							+ "1. Enter a new Car to the inventory (password required)"+"\n"
							+ "2. Change information of an existing Car (password required)"+"\n"
							+ "3. Display all the Cars with specific make and model"+ "\n"
							+ "4. Display all the Cars with the given price range"+"\n"
							+ "5. Quit \n"
							+ "Please enter your choice> ");
					
					 prompt = kb.nextInt();
					 
					 //the program does not terminate unlike option 1, so count is reset 
					 //to allow for 3 tries
					 count2 = 1;
					 
				}
			
			//option 3
			}else if (prompt == 3) {
				
				//asks user for make and model
				System.out.print("Please enter a make: ");
				String user_make = kb.next();
				
				System.out.print("Please enter a model: ");
				String user_model = kb.next();
				
				//plugs it into the findCarBy Static method which is explained later in the code
				Cardriver.findCarBy(user_make, user_model, carDatabase);
				
				//redisplay the main menu (a static method could probably have been used
				//instead of continuously printing out the main menu)
				System.out.print("\nWhat do you want to do?"+"\n"
						+ "1. Enter a new Car to the inventory (password required)"+"\n"
						+ "2. Change information of an existing Car (password required)"+"\n"
						+ "3. Display all the Cars with specific make and model"+ "\n"
						+ "4. Display all the Cars with the given price range"+"\n"
						+ "5. Quit \n"
						+ "Please enter your choice> ");
				
				 prompt = kb.nextInt();
			
			//option 4
			}else if (prompt == 4) {
				
				//prompts the user for a minimal and maximum price
				System.out.print("Please enter a minimum price: ");
				int input_min = kb.nextInt();
				
				System.out.print("Please enter a maximum price: ");
				int input_max = kb.nextInt();
				
				//the findCarsWithinPriceRange is then invoked with these inputs
				Cardriver.findCarsWithinPriceRange(input_min, input_max, carDatabase);
				
				//main menu redisplayed
				System.out.print("\nWhat do you want to do?"+"\n"
						+ "1. Enter a new Car to the inventory (password required)"+"\n"
						+ "2. Change information of an existing Car (password required)"+"\n"
						+ "3. Display all the Cars with specific make and model"+ "\n"
						+ "4. Display all the Cars with the given price range"+"\n"
						+ "5. Quit \n"
						+ "Please enter your choice> ");
				
				 prompt = kb.nextInt();
			
			//option 5
			}else if (prompt == 5) {
				//ending message and simple break statement to end the program
				System.out.print("Thank you for using the Car inventory program. Have a nice day!");
				break;
				
				
				
			}
		kb.close();

	}
		
		
}
	//findCarBy takes in a make, model, and an array of car objects
	//the user will only enter the make and model however
	private static void findCarBy(String make, String model, Car [] carDatabase) {
		
		//count keeps track of an object in the array so that 
		//it knows when a given make and model is present
		int count = 0;
		
		//a for loop going over every object within the car database
		for (int i = 0; i < carDatabase.length; i++) {
			
			//if the make and model of the Car object at a given index are the same
			//this is determined bay making everything to lowercase and comparing them
			//in order to see if there are no spelling mistakes, so uppercase and lowercase
			//makes/models will be considered the same as they ought to be
			if(carDatabase[i].getMake().toLowerCase().compareTo(make.toLowerCase()) == 0 && 
			   carDatabase[i].getModel().toLowerCase().compareTo(model.toLowerCase()) == 0) {
				
				//the index is kept track of the objects which satisfy the condition
				count++;
				//the relevant information on the car Object is printed if the condition is met
				System.out.print(carDatabase[i].toString());
			
			//if the make and model are not the same and it has reached the end of the array and there are no object which satisfy the condition
			}else if(carDatabase[i].getMake().toLowerCase().compareTo(make.toLowerCase()) != 0 && 
					  carDatabase[i].getModel().toLowerCase().compareTo(model.toLowerCase()) != 0 && count == 0 && i == carDatabase.length-1) {
				
				//a message lets the user know that no such cars of the make and model exist
				System.out.print("Sorry there are no cars of this make and model.");
			}
			
		}
	}

	//much like the static method directly above, this static method
	//takes a min and max entered by user, but also a Car object array
	private static void findCarsWithinPriceRange(int min, int max, Car [] carDatabase) {
		
		//for loop going through all the indexes in the object array
		for (int i = 0; i < carDatabase.length; i++) {
			
			//if the price of a given Object in the car array is bigger or equal to the minimum value
			//and is smaller or equal to the maximum amount
			if(carDatabase[i].getPrice() >= min && carDatabase[i].getPrice() <= max) {
				
				//the given car's information are printed using toString()
				System.out.print(carDatabase[i].toString());
			
			//else if the Price of a given car is smaller than the minimum or bigger than the maximum and it is the 
			//the last object in the array (implying all the other objects have not satisfied the above condition)
			}else if(carDatabase[i].getPrice() < min || carDatabase[i].getPrice() > max && (i == carDatabase.length-1)){
				
				//then there are no cars which correspond to the price range
				System.out.print("Sorry there are no cars within this price range.");
			}
		}
	}
}
