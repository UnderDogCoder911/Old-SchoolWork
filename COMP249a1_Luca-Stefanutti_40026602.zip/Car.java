/**
 * 
 * @author Luca Stefanutti ID:40026602
 * COMP249
 * Assignment #1
 * July 17 2019
 * 
 */
/*
 * Assignment 1
 * Part 1
 * Luca Stefanutti 40026602
 */
public class Car {
	
	private String make;
	private String model;
	private int year;
	private int price;
	private static int numberofCars = 0;
	
	/**
	 * The default constructor for a Car object
	 * @param make The make of a car in type String
	 * @param model The model of a car in type String
	 * @param year The year of a car in type integer
	 * @param price The price of a car in type integer
	 */
	public Car(String make, String model, int year, int price) {
		
		this.make = make;
		this.model = model;
		this.year = year;
		this.price = price;
		numberofCars++;
		
	}
	
	/**
	 * A simple getter for the make of a object Car
	 * @return the make of the object Car
	 */
	
	public String getMake() {
		return this.make;
	}
	
	/**
	 * The setter for the make of a Car
	 * @param make Takes a String make to change the make of the Car object
	 */

	public void setMake(String make) {
		this.make = make;
	}
	/**
	 * A simple getter for the model of a object Car
	 * @return the model of the object Car
	 */
	public String getModel() {
		return this.model;
	}
	
	/**
	 * The setter for the model of a Car
	 * @param model Takes a String model to change the model of the Car object
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * A simple getter for the year of a object Car
	 * @return the year of the object Car
	 */
	public int getYear() {
		return this.year;
	}
	/**
	 * The setter for the year of a Car
	 * @param year Takes a int year to change the year of the Car object
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * A simple getter for the price of a object Car
	 * @return the price of the object Car
	 */
	public int getPrice() {
		return this.price;
	}
	/**
	 * The setter for the price of a Car
	 * @param price Takes a int price to change the price of the Car object
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	/**
	 * A overriden toString() method from the object class
	 * @return returns a String with the relevant information regarding the Car object
	 */
	@Override
	public String toString() {
		return "\nThe make of the car is: " + getMake() + "\n"
				+"The model of the car is: " + getModel() + "\n"
				+"The year of the car is: "+ getYear() + "\n"
				+"The price of the car is: " + getPrice()+ "\n";
	}
	/**
	 * A static method that counts returns the amount of car objects created
	 * @return the integer of number of Car objects created through the constructor
	 */
	public static int findNumberofCreatedCars() {
		return numberofCars;
	}
	/**
	 * an equals method that determines whether 2 Car objects are equal
	 * They are equal if they share the same make and model
	 * @param anotherCar takes another Car object to compare
	 * @return a boolean true or false value
	 */
	public boolean equals(Car anotherCar) {
		if (this.make == anotherCar.getMake() && this.model == anotherCar.getModel()) {
			return true;
		}else {
			return false;
		}
}
}