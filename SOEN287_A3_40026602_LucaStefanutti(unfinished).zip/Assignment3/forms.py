from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, PasswordField, SelectMultipleField, RadioField, \
    SelectField, BooleanField
from wtforms.fields.html5 import EmailField, DateField, IntegerField
from wtforms.validators import InputRequired, Email, Length, Regexp, ValidationError, NumberRange, DataRequired, EqualTo
from wtforms.widgets import ListWidget, CheckboxInput


# from wtforms_components import ColorField


class CheckboxField(SelectMultipleField):
    widget = ListWidget(prefix_label=False)
    option_widget = CheckboxInput()


class SurveyForm(FlaskForm):
    name = StringField('First name', validators=[InputRequired()])
    lastname = StringField('Last name', validators=[InputRequired()])
    email = EmailField('Email', validators=[InputRequired(), Email()])
    Q1 = RadioField('Q1. What needs to be improved on the current website?', validators=[InputRequired()],
                    choices=[('layout', 'The Layout?'),
                             ('style', 'The Style?'),
                             ('more dynamic', 'More dynamic and responsive pages?'),
                             ('more pages', 'Additional Pages?')],
                    render_kw={'required': True})

    Q2 = CheckboxField('Q2. What future pages and/or functionalities would you like to see?',
                       validators=[InputRequired()],
                       choices=[('animations', 'Animations'), ('forums', 'Discussion Forums'), ('fan art', 'Fan Art'),
                                ('contact/about', 'Contact/About'), ('whnews', 'WarHammer News')],
                       render_kw={'required': True})
    Q3 = SelectField('Q3. Impressions of the page so far?', validators=[InputRequired()],
                     choices=[('5', '5 - Awesome'), ('4', '4 - Great'), ('3', '3 - Average'), ('2', '2 - Needs Work'),
                              ('1', '1 - Execution by firing squad')])
    Q4 = IntegerField('Q4. If you needed to pay anywhere between $0 and $10, How much would you want to pay to support '
                      'this website?', validators=[InputRequired(), NumberRange(0, 10)])
    Q5 = BooleanField('Q5. Would you like to send in your email?')

    message = TextAreaField('Additional Comments?', validators=[InputRequired(), Length(0, 200)])


class LoginForm(FlaskForm):
    user = StringField('Enter Username: ', validators=[DataRequired()])
    password = PasswordField('Enter Password: ', validators=[DataRequired()])
    submit = SubmitField('login')


def validate_password(field):
    with open('data/common_passwords.txt') as f:
        for line in f.readlines():
            if field.data == line.strip():
                raise ValidationError('Your password is too common.')


class RegisterForm(FlaskForm):
    username = StringField('Username',
                           validators=[InputRequired(),
                                       Length(4, 64)])
    email = EmailField('Email', validators=[InputRequired(), Email()])
    password = PasswordField('Password', validators=[InputRequired(),
                                                     Length(8)])
    password2 = PasswordField('Repeat password',
                              validators=[InputRequired(),
                                          EqualTo('password', message='Passwords must match.')])
    submit = SubmitField('Login')

