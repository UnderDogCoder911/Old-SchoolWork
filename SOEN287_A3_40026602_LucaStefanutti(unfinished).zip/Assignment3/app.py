import csv


from flask import Flask, render_template, redirect, url_for, session, flash

from forms import SurveyForm

app = Flask(__name__)
app.secret_key = "ThunderHouse111"

@app.route('/')
def home_page():
    return render_template('TemplateMainPage.html')


@app.route('/Lore')
def lore_page():
    return render_template('TemplateLore.html')


@app.route('/GameRules')
def game_page():
    return render_template('TemplateGameRulesPage.html')


@app.route('/Links')
def links_page():
    return render_template('TemplateVariousExternalLinksPage.html')


@app.route('/Videos')
def videos_page():
    return render_template('TemplateVideoPage.html')


@app.route('/Survey', methods=['GET', 'POST'])
def survey_form():
    form = SurveyForm()
    if form.validate_on_submit() and form.Q5.data is True:
        with open('data/messages.csv', 'a') as f:
            writer = csv.writer(f)
            writer.writerow(
                [form.name.data, form.lastname.data, form.email.data, form.Q1.data, form.Q2.raw_data,
                 'Rating of ' + form.Q3.data,
                 form.Q4.data, form.message.data])
        return redirect(url_for('ack_page', name=form.name.data, lastname=form.lastname.data))

    if form.validate_on_submit() and form.Q5.data is False:
        with open('data/messages.csv', 'a') as f:
            writer = csv.writer(f)
            writer.writerow(
                [form.name.data, form.lastname.data, form.Q1.data, form.Q2.raw_data,
                 'Rating of ' + form.Q3.data,
                 form.Q4.data, form.message.data])
        return redirect(url_for('ack_page', name=form.name.data, lastname=form.lastname.data))
    return render_template('SurveyForm.html', form=form)


@app.route('/SurveySent/<name><lastname>')
def ack_page(name, lastname):
    return render_template('SurveySent.html', name=name, lastname=lastname)


if __name__ == '__main__':
    app.run(debug=True)
