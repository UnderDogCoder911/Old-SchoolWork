function validateName(){
    const re = /^[A-Za-z]{2,20}$/;
    const FirstnameIn = document.getElementById("name");
    const LastnameIn = document.getElementById("lastname");

    FirstnameIn.value = FirstnameIn.value.trim();
    LastnameIn.value = LastnameIn.value.trim();

    if(re.test(FirstnameIn.value)){
        FirstnameIn.className="";
    }else{
        FirstnameIn.classList.add("alert");
        FirstnameIn.classList.add("alert-danger");
    }

    if(re.test(LastnameIn.value)){
        LastnameIn.className="";
    }else{
       LastnameIn.classList.add("alert");
       LastnameIn.classList.add("alert-danger");
    }
}