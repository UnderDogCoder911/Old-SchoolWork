/*
 * Q3.c
 *
 *  Created on: Nov. 24, 2019
 *      Author: Ian Lopez & Luca Stefanutti
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef struct node{
 char str[255];
 struct node * next;
}node;

//Declarations of functions
node * insert_dictionary_order(char * word, node * head);
void  print_list(node * head);
bool hasPeriod(node * head);
void deleteList(node * head);

int main(){

 node *head = NULL;
 head=(node*)malloc(sizeof(node)); // head is an empty node
 char word[255];
 printf("\nEnter a word: ");

 if(scanf("%s", word)!=EOF){
	 head = (node*)malloc(sizeof(node));
	 head = insert_dictionary_order(word, head);
	 print_list(head);
	 deleteList(head);
 }
 else{
	 printf("EOF");
 }
 return 0;
	}
//Rearrange the linked list according to alphabetical order
node * insert_dictionary_order(char * word, node * head){
	char c, input[255];
	node *newNode, *prevNode, *currNode;
	bool period = false;

	while(!hasPeriod(head)){
		// Allocate space
		newNode = (struct node *)malloc(sizeof(struct node));
		// Read input
		// If this is the first node
		if(head->next == NULL){
			// Copy data to newNode
			strcpy(newNode->str, word);
			newNode->next = NULL;
			head->next = newNode;

			if(hasPeriod(head)){
				printf("%s\n",head->str);
				return head;
				}
			}
			else{
			printf("\nEnter a word: ");
			if(scanf("%s", input)!= EOF){
				// Copy data to newNode
				strcpy(newNode->str, input);
				newNode->next = NULL;
				prevNode = head;
				currNode = head->next;
				// Iterate while there is node in list left and currNode comes before newNode
				while(currNode != NULL && (strcmp(currNode->str, newNode->str) < 0)){//check to see if the current node
					//is less than the new node so
					/*
                     The strcmp() compares two strings character by character.
   	                 If the first character of two strings is equal, the next character of two strings are compared.
   	                 This continues until the corresponding characters of two strings are different or a null character '\0' is reached.
					 */
					prevNode = currNode;
					currNode = currNode->next;
				}
				// Inserting new Node
				newNode->next = currNode;
				prevNode->next = newNode;
			}
			else{
				printf("EOF");
				return head;
				}
			}
	}
	return head;
	}

bool hasPeriod(node * head){
	node * p =head;
	const char *invalid_characters = ".";

	while(p!=NULL){
		char * c = p->str;
		while (*c)
		{
			if (strchr(invalid_characters, *c))
			{
				printf("The file is terminated by a single dot: %c\n", *c);
				*c = ' ';
				return true;
			}
			c++;
		}
		p = p->next;
	}
	return false;
	}

 void print_list(struct node *head){
	 struct node *currNode = head->next;
     	 if(head == NULL){
     		 printf("\nList is empty.");
     		 return;
     	 }
     	 printf("\nThe list is: \n");
     	 while(currNode != NULL){ // Traverse list and print
     		 printf("%s ", currNode->str);
     		 currNode = currNode->next;
     	 }
     	 printf(".");
 }
 void deleteList(struct node *head){
   struct node *prevNode, *currNode = head->next;

   while(currNode != NULL){ // Traverse list and delete nodes
       prevNode = currNode;
       currNode = currNode->next;
       free(prevNode);
     }
     free(head);
     }


