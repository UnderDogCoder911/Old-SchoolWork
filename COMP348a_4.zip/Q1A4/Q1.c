/*
 * Q1.c
 *
 *  Created on: Nov. 20, 2019
 *      Author: Luca Stefanutti
 */
#include<stdio.h>

int main(int argc,char* argv[])
{
	int const EXIT_FAILURE = -1;
	void exit(int status);

//if no arguments are passed in command line
if(argc <= 1){
	printf("The filename is missing \n"
			"Usage: %s", argv[0]);//the default path of execution is printed
	exit(EXIT_FAILURE);

} else if(argc > 1) { //if there are arguments

	FILE * fp;
	char ch, nextc;
	fp = fopen(argv[1], "r"); //create a file pointer to that file in commandline

//to check if the argument is successfully opened as a file
if(fp == NULL){
	printf("Opening file error");
}


	nextc = fgetc (fp); //takes 1st char in file

while (nextc != EOF)//a while loop that will read one character at a time until End of File
{

	ch = nextc;//ch becomes the previous character
	nextc = fgetc (fp);//nextc becomes the current character

	if ((ch == '/') && (nextc == '*'))//if it is the start of a multiline comment
	{
		ch = fgetc (fp);
		nextc = fgetc (fp);//get the next two characters

		while (!((ch == '*') && (nextc == '/')))//while not at the end of the multiline
		{
		ch = nextc;
		nextc = fgetc (fp);//skip all the content within the multiline
		}

		nextc = fgetc (fp);
		continue;//to skip the last */ characters

	}else if((ch=='/') && (nextc == '/'))//if it is a singleline comment
	{
		nextc = fgetc (fp);//grab the next charachter

		while (!(nextc == '\n')){//while it's not the end of the singleline
			nextc = fgetc (fp);//keep on getting the next character
		}
			nextc = fgetc (fp); //grab the character after the singleline
			continue; //sets ch to the charcter after the singleline effectively skipping all the content
}

	printf("%c", ch);//simply print out ch to get the contents of the c file
}
	fclose(fp);//close the file after it is completely read
	return 0;

}
}

