/*
 * Q2.c
 *
 *  Created on: Nov. 20, 2019
 *      Author: Ian Lopez, Luca Stefanutti
 */
#include <stdio.h>
#include <inttypes.h>
void floatToBin(float flo) {
 union data {
   float f;
   uint32_t i;
   };
 union data u;

 u.f = flo;

 char output[40];
 for (int j = 31; j >= 0; j--) {
   if (u.i % 2) {
     output[j] = 'X';
   } else {
     output[j] = '0';
   }
   u.i >>= 1;
 }

 printf("\n\n---------------------PART B---------------------\n\n");
 printf("Number %f in binary representation is:\n", flo);
 for (int i = 0; i <= 31; i ++) {
   if (!(i % 4)) {
     printf(" ");
   }
   printf("%c", output[i]);
 }
}

void doubleToBin(double dou) {
 union data {
   double d;
   uint64_t i;
   };

 union data u;
 u.d = dou;
 char output[63];
 printf("\n\n---------------------PART B---------------------\n\n");
 printf("Number %lf in binary representation is:\n", dou);
 for (int j = 63; j >= 0; j--) {
   if (u.i % 2) {
     output[j] = 'X';
   } else {
     output[j] = '0';
   }
   u.i >>= 1;
 }
 for (int i = 0; i <= 63; i ++) {
   if (!(i % 4)) {
     printf(" ");
   }
   printf("%c", output[i]);
 }
}

int main(){
char user_in;
printf("[F]loat or [D]ouble? ");
scanf("%c", &user_in);
printf("%c\n", user_in);
if(user_in == 'F' || user_in == 'f'){
      float f;
      printf("Enter the number: ");
      scanf("%f", &f);
      printf("---------------------PART A---------------------\n\n");
      printf("Number %f in binary point representation is:\n", f);
      unsigned char* bytes = (unsigned char*)(void*)&f;
      for(int i = 3 ; i >= 0 ; i--){
          for(int j = 7 ; j >= 0 ; j--){
              if(j == 3){
                  printf(" ");
              }
              if(bytes[i] & (1<<j)){
                  printf("%c", 'X');
              }else{
                  printf("%c", '0');
              }
          }
          printf(" ");
      }
      floatToBin(f);
  }
  if(user_in == 'D' || user_in == 'd'){
      double f;
      printf("Enter the number: ");
      scanf("%lf", &f);
      printf("---------------------PART A---------------------\n\n");
      printf("Number %lf in binary point representation is:\n", f);
      unsigned char* bytes = (unsigned char*)(void*)&f;
      for(int i = 7 ; i >= 0 ; i--){
          int bit = (int)bytes[i];
          for(int j = 7 ; j >= 0 ; j--){
              if(j == 3){
                  printf(" ");
              }
              if(bit & (1<<j)){
                  printf("%c", 'X');
              }else{
                  printf("%c", '0');
              }
          }
          printf(" ");
      }
      doubleToBin(f);
  }
}

