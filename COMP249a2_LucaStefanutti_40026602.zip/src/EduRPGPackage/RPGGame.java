/**
 * Luca Stefanutti 40026602
 * COMP249
 * Assignment 2
 * Saturday July 27 2019
 */

package EduRPGPackage;

import VideoGamePackage.VideoGame;



public class RPGGame extends VideoGame{
	private String gameWorld;
	
	/**
	 * Default constructor for the RPGGame class
	 */
	public RPGGame() {
		gameWorld = "Earth 2047";
	}
	
	/**
	 * Parameterized constructor for the RPGGame class 
	 * @param name name of the RPGGame in String
	 * @param numPlayers number of players in integer
	 * @param gameTime the average game time in minutes represented by integer
	 * @param gamePrice the price of the RPG in dollars represented by integer
	 * @param gameStudio the game studio in String
	 * @param GP the gaming platform enum
	 * @param gameWorld the game world for the RPG in String
	 */
	public RPGGame(String name, int numPlayers, int gameTime, 
				int gamePrice, String gameStudio, 
					gamingPlatform GP, String gameWorld) {
		
		
		super(name, numPlayers, gameTime, gamePrice, gameStudio, GP);
		
		this.gameWorld = gameWorld;
	}
	
	/**
	 * Copy constructor for the RPG class
	 * @param someRPG takes another RPG object and invokes the copy constructor of the parent as well as assigning the attributes of the other RPG to the new copy
	 */
	
	public RPGGame(RPGGame someRPG) {
		super(someRPG);
//		name = someRPG.name;
//		numPlayers = someRPG.numPlayers;
//		gameTime = someRPG.gameTime;
//		gamePrice = someRPG.gamePrice;
//		gameStudio = someRPG.gameStudio;
//		Gamingplatform = someRPG.Gamingplatform;
		gameWorld = someRPG.gameWorld;
	}
	/**
	 * simple getter for the game world attribute
	 * @return returns the game world as a String
	 */
	public String getGameWorld() {
		return gameWorld;
	}

	/**
	 * simple setter for the game world
	 * @param gameWorld accepts a gameworld String parameter which assigns it to the gameworld attribute to be modified
	 */
	public void setGameWorld(String gameWorld) {
		this.gameWorld = gameWorld;
	}
	/**
	 * Overriden toString method from the VideoGame class
	 * @return returns a string with the relevant information for the RPGGame attributes
	 */
	public String toString() {
		return "The Name of the game is: "+ this.getName()
				+"\nThe number of players is: " + this.getNumPlayers()
				+"\nThe game Time is: "+ this.getGameTime() +" minutes"
				+"\nThe game price is: "+ this.getGamePrice() + "$"
				+"\nThe game studio is: "+ this.getGameStudio()
				+"\nThe gaming platform is: "+ this.getGamingplatform()
				+"\nThe game world is: " + gameWorld;
}
	/**
	 * Overriden toString method from the VideoGame class
	 * @param someObj a object is passed as parameter 
	 * @return true if the object passed is of the same class and has all the same attributes, false otherwise
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			RPGGame someRPG = (RPGGame)someObj;
			return ((this.getName().equalsIgnoreCase(someRPG.getName()))
				&& (this.getNumPlayers() == someRPG.getNumPlayers())
				&& (this.getGameTime() == someRPG.getGameTime())
				&& (this.getGamePrice() == someRPG.getGamePrice())
				&& (this.getGameStudio().equalsIgnoreCase(someRPG.getGameStudio()))
				&& (this.getGamingplatform().equals(someRPG.getGamingplatform()))
				&& this.gameWorld.equalsIgnoreCase(someRPG.gameWorld));
			

		}
}
}
