/**
 * Luca Stefanutti 40026602
 * COMP249
 * Assignment 2
 * Saturday July 27 2019
 */

package EduRPGPackage;

import VideoGamePackage.VideoGame;

public class EducationalGame extends VideoGame {
	private String subjectLearnt;
	
	/**
	 * Default Constructor for Educational Games
	 */
	public EducationalGame() {
		subjectLearnt = "Mass Robotic Violence";
	}
	
	/**
	 * Parameterized Constructor for Educational Games
	 * @param name the name of an educational game in String
	 * @param numPlayers the number of players in integer
	 * @param gameTime the game time in minutes represented by integer
	 * @param gamePrice the price of a game in dollars represented by integer
	 * @param gameStudio the name of the game studio in String
	 * @param GP the enum gamingplatform on which the game runs
	 * @param subjectLearnt the subject being taught by the game in String
	 */
	public EducationalGame(String name, int numPlayers, int gameTime, 
							int gamePrice, String gameStudio, 
							gamingPlatform GP, String subjectLearnt) {
		
		super(name, numPlayers, gameTime, gamePrice, gameStudio, GP);
		this.subjectLearnt = subjectLearnt;
	}
/**
 * The copy constructor for the Educational game
 * @param someEduGame takes in an educational game and uses it to call the copy constructor of the parent as well as copying the attributes found in the child
 */
	public EducationalGame(EducationalGame someEduGame) {
		super(someEduGame);
//		name = someEduGame.name;
//		numPlayers = someEduGame.numPlayers;
//		gameTime = someEduGame.gameTime;
//		gamePrice = someEduGame.gamePrice;
//		gameStudio = someEduGame.gameStudio;
//		Gamingplatform = someEduGame.Gamingplatform;
		subjectLearnt = someEduGame.subjectLearnt;
	}
/**
 * simple getter for the subject taught by the game
 * @return returns what the user will have learned
 */
	public String getSubjectLearnt() {
		return subjectLearnt;
	}

	/**
	 * simple setter for the subject learnt
	 * @param subjectLearnt takes in a string to modify the subject learnt
	 */
	public void setSubjectLearnt(String subjectLearnt) {
		this.subjectLearnt = subjectLearnt;
	}
	
	/**
	 * toString method overriden from the VideoGame Class
	 * @return returns a string with all the relevant information for an object of type EducationalGame
	 */
	public String toString() {
		return "The Name of the game is: "+ this.getName()
				+"\nThe number of players is: " + this.getNumPlayers()
				+"\nThe game Time is: "+ this.getGameTime() +" minutes"
				+"\nThe game price is: "+ this.getGamePrice() + "$"
				+"\nThe game studio is: "+ this.getGameStudio()
				+"\nThe gaming platform is: "+this.getGamingplatform()
				+"\nThe subject learnt is: "+subjectLearnt;
}
	/**
	 * equals method overriden from VideoGame class
	 * @param someObj an object is passed a parameter
	 * @return returns true if the inputed object is of the same class and has all the same attributes returns false otherwise
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			EducationalGame someEduG = (EducationalGame)someObj;
			return ((this.getName().equalsIgnoreCase(someEduG.getName()))
				&& (this.getNumPlayers() == someEduG.getNumPlayers())
				&& (this.getGameTime() == someEduG.getGameTime())
				&& (this.getGamePrice() == someEduG.getGamePrice())
				&& (this.getGameStudio().equalsIgnoreCase(someEduG.getGameStudio()))
				&& (this.getGamingplatform().equals(someEduG.getGamingplatform()))
				&& this.subjectLearnt.equalsIgnoreCase(someEduG.subjectLearnt));
			

		}
}
}