/**
 * Luca Stefanutti 40026602
 * COMP249
 * Assignment 2
 * Saturday July 27 2019
 */

package GamePackage;

public class Game {
	private String name;
	private int numPlayers;
	private int gameTime;
	/**
	 * Default constructor for the Game class
	 */
	public Game() {
		name = "TheTerminator2000";
		numPlayers = 4;
		gameTime = 20;
	}
	/**
	 * Parameterized constructor for the Game class
	 * @param name name of the Game in String
	 * @param numPlayers number of players in integer
	 * @param gameTime game time in minutes aka integer
	 */
	public Game(String name, int numPlayers, int gameTime) {
		this.name = name;
		this.numPlayers = numPlayers;
		this.gameTime = gameTime;
	}
	/**
	 * copy constructor for game class
	 * @param anotherGame takes a already defined Game object and assigns its attributes to a newly created Game object
	 */
	public Game(Game anotherGame) {
		name = anotherGame.name;
		numPlayers = anotherGame.numPlayers;
		gameTime = anotherGame.gameTime;
	}
	/**
	 * simple getter for the name of the game
	 * @return returns the name of the game as String
	 */
	public String getName() {
		return name;
	}
	/**
	 * simple setter for the name of the game
	 * @param name takes in a string to set the name of the invoking Game object
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * simple getter for the number of players
	 * @return returns the number of players as int
	 */
	public int getNumPlayers() {
		return numPlayers;
	}
	/**
	 * simple setter for the number of players
	 * @param numPlayers takes an integer to set the number of players on the invoking Game object
	 */
	public void setNumPlayers(int numPlayers) {
		this.numPlayers = numPlayers;
	}
	/**
	 * simple getter for the game time
	 * @return return the game time as integer
	 */
	public int getGameTime() {
		return gameTime;
	}
	/**
	 * simple setter for the game time
	 * @param gameTime takes in an integer to set the game time of an invoking game class
	 */
	public void setGameTime(int gameTime) {
		this.gameTime = gameTime;
	}
	/**
	 * toString method overriden from object
	 * @return returns a string with all the relevant attributes of a Game class object
	 */
	public String toString() {
		return "The Name of the game is: "+ name
				+"\nThe number of players is: " +numPlayers
				+"\nThe game Time is: "+gameTime;
	}
	/**
	 * overriden equals method from object
	 * @param someObj takes in an object as parameter
	 * @return true if all the attributes are equal and both objects are of the same class, false otherwise
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			Game someGame = (Game)someObj; 
			return ((this.name.equalsIgnoreCase(someGame.name))
				&& (this.numPlayers == someGame.numPlayers)
				&& (this.gameTime == someGame.gameTime));
		//MIGHT NEED COMPARETO() INSTEAD OF EQUALS BC OF OVERRIDE IN EVERYCLASS
		}
	}
}
