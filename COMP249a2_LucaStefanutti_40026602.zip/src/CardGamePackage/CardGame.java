package CardGamePackage;

import GamePackage.Game;

public class CardGame extends Game{
	private int numberOfCards;
	private int numCardTypes;
	
	/**
	 * Default constructor for the CardGame class
	 */
	public CardGame(){
		numberOfCards = 60;
		numCardTypes = 12;
	}
	/**
	 * Parameterized constructor for the CardGame class
	 * @param name the name of the CardGame String
	 * @param numPlayers the number of players in integer
	 * @param gameTime the average game time in minutes represented by integer
	 * @param numberOfCards the number of total cards in the game in int
	 * @param numCardTypes the various different card types in int
	 */
	public CardGame(String name, int numPlayers, int gameTime,
					int numberOfCards, int numCardTypes) {
		
		super(name, numPlayers, gameTime);
		this.numberOfCards = numberOfCards;
		this.numCardTypes = numCardTypes;
	}
	
	/**
	 * Copy constructor for the CardGame class
	 * @param someCG takes another Cardgame object already created as parameter and assigns all of its parameters to the newly created copy
	 */
	public CardGame(CardGame someCG) {
		super(someCG);
//		name = someCG.name;
//		numPlayers = someCG.numPlayers;
//		gameTime = someCG.gameTime;
		numberOfCards = someCG.numberOfCards;
		numCardTypes = someCG.numCardTypes;
		
	}
/**
 * simple getter for the number of cards
 * @return returns the number of cards in integer
 */
	public int getNumberOfCards() {
		return numberOfCards;
	}
/**
 * simple setter for the number of cards
 * @param numberOfCards takes an integer value to be set as the new value for the number of cards of a given CardGame
 */
	public void setNumberOfCards(int numberOfCards) {
		this.numberOfCards = numberOfCards;
	}
/**
 * simple getter for the number of card types
 * @return returns an int for number of card types
 */
	public int getNumCardTypes() {
		return numCardTypes;
	}
/**
 * simple setter for number of cards types
 * @param numCardTypes takes an integer value to set the new value for the number of card types of a given CardGame
 */
	public void setNumCardTypes(int numCardTypes) {
		this.numCardTypes = numCardTypes;
	}
	/**
	 * toString method overriden from Game class
	 * @return a String with all the relevant attributes of a Cardgame
	 */
	public String toString() {
		return "The Name of the game is: "+ this.getName()
				+"\nThe number of players is: " +this.getNumPlayers()
				+"\nThe game time is: "+this.getGameTime()
				+"\nThe number of cards is: "+ numberOfCards
				+"\nThe number of card types is: "+numCardTypes;
	}
	/**
	 * equals method overriden from Game class
	 * @param someObj takes in some object
	 * @return true if all the attributes of the parameter object are equal to the attributes of the invoking object and both are of the same class, false otherwise
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			CardGame someCG = (CardGame)someObj; 
			return ((this.getName().equalsIgnoreCase(someCG.getName()))
				&& (this.getNumPlayers() == someCG.getNumPlayers())
				&& (this.getGameTime() == someCG.getGameTime())
				&& (this.numberOfCards == someCG.numberOfCards)
				&& (this.numCardTypes == someCG.numCardTypes));
		
		}
	}
}

