/**
 * Luca Stefanutti 40026602
 * COMP249
 * Assignment 2
 * Saturday July 27 2019
 */

package BoardGamePackage;

import GamePackage.Game;

public class BoardGame extends Game {
	private boolean timedTurns;
	
	/**
	 * default constructor for the BoardGame Class
	 */
	public BoardGame() {
		timedTurns = true;
	}
	
	/**
	 * Parameterized constructor for BoardGame Class
	 * @param name name of the boardgame as a string
	 * @param numPlayers the number of players as an integer
	 * @param gameTime the amount of game times in minute as integer
	 * @param timedTurns whether or not the boardgame has timed turns as a boolean
	 */
	public BoardGame(String name, int numPlayers, int gameTime, boolean timedTurns) {
		super(name, numPlayers, gameTime);
		this.timedTurns = timedTurns;
	}
	
	/**
	 * Copy constructor for the BoardGame Class
	 * @param someBG another boardgame object that will have all of its attributes copied
	 */
	public BoardGame(BoardGame someBG) {
		super(someBG);
//		name = someBG.name;
//		numPlayers = someBG.numPlayers;
//		gameTime = someBG.gameTime;
		timedTurns = someBG.timedTurns;
	}
	
	
	/**
	 * simple getter for Timed Turns attributed
	 * @return returns true or false depending on whether the boardgame has timed turns or not
	 */

	public boolean isTimedTurns() {
		return timedTurns;
	}

	/**
	 * simple setter to change the boolean attributed timed turns
	 * @param timedTurns takes a boolean value to change the value of the attribute
	 */
	public void setTimedTurns(boolean timedTurns) {
		this.timedTurns = timedTurns;
	}
	/**
	 * Override of the toString method from the Game Class
	 * @return returns a long String with all the relevant attributes clearly labeled
	 */
	public String toString() {
		return "The Name of the game is: "+ this.getName()
				+"\nThe number of players is: " +this.getNumPlayers()
				+"\nThe game Time is: "+this.getGameTime()
				+"\nWheather the game has timed turns is: " + timedTurns;
	}
	/**
	 * an equals method Overridden from the Game Class
	 * @param someObj an object is passed as parameter
	 * @return returns a true or false depending on weather all the attributes are the same and the object is part of the same class
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			BoardGame someBG = (BoardGame)someObj; 
			return ((this.getName().equalsIgnoreCase(someBG.getName()))
				&& (this.getNumPlayers() == someBG.getNumPlayers())
				&& (this.getGameTime() == someBG.getGameTime())
				&& (this.timedTurns == someBG.timedTurns));
		
		}
	}
}
