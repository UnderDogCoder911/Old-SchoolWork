/**
 * Luca Stefanutti 40026602
 * COMP249
 * Assignment 2
 * Saturday July 27 2019
 */

package VideoGamePackage;

import GamePackage.Game;

public class VideoGame extends Game {
	private int gamePrice;
	private String gameStudio;
	public enum gamingPlatform{XBOXOne,  PS4,  IOS, ANDROID};
	private gamingPlatform Gamingplatform;
	
	/**
	 * Default constructor for the VideoGame class
	 */
	public VideoGame(){
		gamePrice = 40;
		gameStudio = "SkyNetGames";
		Gamingplatform = gamingPlatform.XBOXOne;
	}
	/**
	 * Parameterized constructor for the VideoGame class
	 * @param name name of the VideoGame of String
	 * @param numPlayers the number of players in integer
	 * @param gameTime the game time in integer
	 * @param gamePrice the game price in integer
	 * @param gameStudio the studio name in string
	 * @param GP the enum gamingplatform
	 */
	public VideoGame(String name, int numPlayers, int gameTime, 
					int gamePrice, String gameStudio, gamingPlatform GP) {
		
		super(name, numPlayers, gameTime);
		this.gamePrice = gamePrice;
		this.gameStudio = gameStudio;
		this.Gamingplatform = GP;
	}
	/**
	 * copy constructor for VideoGame class
	 * @param someVG takes in another VideoGame object and assigns its value to the new copy object
	 */
	public VideoGame(VideoGame someVG) {
		super(someVG);
//		name = someVG.name;
//		numPlayers = someVG.numPlayers;
//		gameTime = someVG.gameTime;
		gamePrice = someVG.gamePrice;
		gameStudio = someVG.gameStudio;
		Gamingplatform = someVG.Gamingplatform;
		gamePrice = someVG.gamePrice;
		gameStudio = someVG.gameStudio;
		Gamingplatform = someVG.Gamingplatform;
	}
/**
 * simple getter for the game price
 * @return returns the integer for the game price
 */
	public int getGamePrice() {
		return gamePrice;
	}
/**
 * simple setter for the game price
 * @param gamePrice sets the game price with an integer parameter
 */
	public void setGamePrice(int gamePrice) {
		this.gamePrice = gamePrice;
	}
/**
 * simple getter for the game studio name
 * @return returns the name for the game studio in String
 */
	public String getGameStudio() {
		return gameStudio;
	}
/**
 * simple setter for the game studio
 * @param gameStudio takes a string to set the game studio
 */
	public void setGameStudio(String gameStudio) {
		this.gameStudio = gameStudio;
	}
/**
 * simple getter for the gamingplatform enum
 * @return returns a gaming platform enum
 */
	public gamingPlatform getGamingplatform() {
		return Gamingplatform;
	}
/**
 * simple setter for gaming platform enum
 * @param gamingplatform takes a gamingplatform enum to set the invoking object's gamimgplatform
 */
	public void setGamingplatform(gamingPlatform gamingplatform) {
		Gamingplatform = gamingplatform;
	}
	/**
	 * override of the toString method from Game class
	 * @return returns a string with all the relevant attributes of the VideoGame class
	 */
	public String toString() {
		return "The Name of the game is: "+ this.getName()
				+"\nThe number of players is: " + this.getNumPlayers()
				+"\nThe game Time is: "+ this.getGameTime() +" minutes"
				+"\nThe game price is: "+ gamePrice + "$"
				+"\nThe game studio is: "+ gameStudio
				+"\nThe gaming platform is: "+ Gamingplatform;
}
	/**
	 * equals method that overrides from game class
	 * @param someObj takes in an object
	 * @return returns true if all the attributes are equal and the parameterized object is of the same class, else it returns false
	 */
	public boolean equals(Object someObj) {
		if(someObj == null || someObj.getClass() != this.getClass()) {
			return false;
		}else {
			VideoGame someVG = (VideoGame)someObj;
			return ((this.getName().equalsIgnoreCase(someVG.getName()))
				&& (this.getNumPlayers() == someVG.getNumPlayers())
				&& (this.getGameTime() == someVG.getGameTime())
				&& (this.gamePrice == someVG.gamePrice)
				&& (this.gameStudio.equalsIgnoreCase(someVG.gameStudio))
				&& (this.Gamingplatform.equals(someVG.Gamingplatform)));
			//MIGHT NEED COMPARETO() INSTEAD OF EQUALS BC OF OVERRIDE IN EVERYCLASS

		}
	}
}
