package DriverPackage;

import BoardGamePackage.BoardGame;

import CardGamePackage.CardGame;

import EduRPGPackage.EducationalGame;

import EduRPGPackage.RPGGame;

import GamePackage.Game;

import VideoGamePackage.VideoGame;

import VideoGamePackage.VideoGame.gamingPlatform;
 
public class driver {
/*
 * Assignment 2 
 * Part 2
 * Written by: Luca Stefanutti
 */
	
	//a static method that takes in a array with Game type objects
	public static Game[] gameSimilarTo(Game[] someGameArray) {
		
		//making a new array of length equal to the array we have passed through
		int i = 0;
		Game[] otherGameArray = new Game[someGameArray.length];
		
		//using a for each loop to go over every object of type Game in the passed array, copying them using the copy constructor
		//and assigning them to the newly created array
		for(Game game : someGameArray) {
			otherGameArray[i] = new Game(someGameArray[i]);
			i++;
		}
	//returning the array with all the objects copied
		return otherGameArray;
	}
	
	public static void main(String[] args) {
		/*
		 * Assignment 2 
		 * Part 1
		 * Written by: Luca Stefanutti
		 */
		
		//Changing all the access to the most restrictive i.e. private to the attributes
		//forces the use of getters and setters to complete constructors in child classes to
		//Game and VideoGame classes, as well as call to the copy constructor using super(object).
		//So access to the variables is limited, however the principal of encapsulation
		//which is centerfold to OOP is conserved, attributes that are protected cannot be accessed
		//outside a given class and thus cannot be tampered with either for neferious or neglectful purposes.
		//Of particular note is that enums cannot be made public especially if accessed from another package and 
		//when extending to another class
		
			System.out.print("Greetings! Welcome to the start of the program!\n\n");
		
			//creating Game objects with all three constructors
		     Game G1 = new Game();
		     Game G2 = new Game("Qbert", 1, 10);
		     Game G3 = new Game(G2);
		     
		     //printing out the results using the respective toString() method
		     System.out.print(G1);
		     System.out.print("\n\n"+G2);
		     System.out.print("\n\n"+G3);
		     
		     //creating an enum gaming platform to plug into the parameterized constructor for Video games
		     gamingPlatform GP1 = gamingPlatform.XBOXOne;
		   
		     //creating VideoGame objects with all three constructors
		     VideoGame VG1 = new VideoGame();
		     VideoGame VG2 = new VideoGame("EDF5", 4, 10, 50, "Sandbox", GP1);
		     VideoGame VG3 = new VideoGame(VG1);
		   
		     //printing out the results using the respective toString() method
		     System.out.print("\n\n"+VG1);
		     System.out.print("\n\n"+VG2);
		     System.out.print("\n\n"+VG3);
		     
		     //creating an enum gaming platform to plug into the parameterized constructor for Educational games
		     gamingPlatform GP2 = gamingPlatform.ANDROID;
		     
		   
		     //creating EducationalGame objects with all three constructors
		     EducationalGame EduG1 = new EducationalGame();
		     EducationalGame EduG2 = new EducationalGame("LeapFrogLearning", 1, 10, 20,"Sandbox",GP2,"French");
		     EducationalGame EduG3 = new EducationalGame(EduG2);
		   
		     //printing out the results using the respective toString() method
		     System.out.print("\n\n"+EduG1);
		     System.out.print("\n\n"+EduG2);
		     System.out.print("\n\n"+EduG3);
		    
		     //creating an enum gaming platform to plug into the parameterized constructor for Role Playing games
		     gamingPlatform GP3 = gamingPlatform.PS4;
		     
		   
		     //creating RPGGame objects with all three constructors
		     RPGGame RPG1 = new RPGGame();
		     RPGGame RPG2 = new RPGGame("ReclaimTheHolyLands", 150, 30, 60, "Sandbox",GP3, "Jeruselem server1");
		     RPGGame RPG3 = new RPGGame(RPG1);
		   
		     //printing out the results using the respective toString() method
		     System.out.print("\n\n"+RPG1);
		     System.out.print("\n\n"+RPG2);
		     System.out.print("\n\n"+RPG3);
		     
		     //creating BoardGame objects with all three constructors
		     BoardGame BG1 = new BoardGame();
		     BoardGame BG2 = new BoardGame("Allies&Axis", 6, 600, false);
		     BoardGame BG3 = new BoardGame(BG2);
		     
		     //printing out the results using the respective toString() method
		     System.out.print("\n\n"+BG1);
		     System.out.print("\n\n"+BG2);
		     System.out.print("\n\n"+BG3);
		     
		     //creating CardGame objects with all three constructors
		     CardGame CG1 = new CardGame();
		     CardGame CG2 = new CardGame("YuGiOh", 2, 30, 500, 6);
		     CardGame CG3 = new CardGame(CG1);
		     
		    //printing out the results using the respective toString() method
		     System.out.print("\n\n"+CG1);
		     System.out.print("\n\n"+CG2);
		     System.out.print("\n\n"+CG3);
		     
		     //Testing the equals method in all classes with the various objects created above
		     //All of them are compared to objects of the same class except EduG2 just to see 
		     //if it will return false upon detecting it not being of the VideoGame class
		     System.out.print("\n\n"+G1.equals(G2));
		     System.out.print("\n\n"+VG1.equals(VG3));
		     System.out.print("\n\n"+EduG2.equals(VG1));
		     System.out.print("\n\n"+RPG3.equals(RPG2));
		     System.out.print("\n\n"+BG1.equals(BG2));
		     System.out.print("\n\n"+CG2.equals(CG3));
		     System.out.print("\n\n"+VG3.equals(VG2));
		     
		     //Creating a Game Array with 14 objects from all 6 classes
		     Game [] GameArray = new Game[14];
		     
		     //populating the Game Array with various objects from the 6 classes
		     GameArray[0] = G1;
		     GameArray[1] = VG2;
		     GameArray[2] = EduG3;
		     GameArray[3] = RPG2;
		     GameArray[4] = BG1;
		     GameArray[5] = CG3;
		     GameArray[6] = G3;
		     GameArray[7] = VG1;
		     GameArray[8] = EduG1;
		     GameArray[9] = BG2;
		     GameArray[10] = RPG3;
		     GameArray[11] = CG1;
		     GameArray[12] = G2;
		     GameArray[13] = EduG2;
		     
		     //initalizing variables that will be used to compare and obtain the values with
		     //max Number of Players, min Game Time and same studio association
		     int maxNumPlayers = GameArray[0].getNumPlayers();
		     int minGameTime = GameArray[0].getGameTime();
		     String GameStudiosame = ((VideoGame)GameArray[1]).getGameStudio();
		    
		     //null game objects into which the game objects with the max number of 
		     //players and min game time will be copied into and later printed
		     Game compareGame = null;
		     Game compareGame2 = null;
		     
		     //initalized index values which will be copied from the for loop upon 
		     //finding the Games with max numplayers and min gametime
		     int Captureindex1 = 0;
		     int Captureindex2 = 0;
		     
		     for(int i = 0; i < GameArray.length; i++) {
		    	
		    	 //if the initalized value for max number of players is smaller than the number of players of another game in the array
		    	 if (maxNumPlayers < GameArray[i].getNumPlayers()) {
		    		 
		    		 //we store the values into the intialized variables that we declared earlier
		    		 maxNumPlayers = GameArray[i].getNumPlayers();
		    		 compareGame = GameArray[i];
		    		 Captureindex1 = i;
		    		 
		    	 }
		     	
		    	//if the initalized value for min game time is bigger than the game time of another game in the array
		    	 if (minGameTime > GameArray[i].getGameTime()) {
		    		 
		    		 //we store the values into the intialized variables that we declared earlier
		    		 minGameTime = GameArray[i].getGameTime();
		    		 compareGame2 = GameArray[i];
		    		 Captureindex2 = i;
		    		 	
		     	}	
		     
		    	 //multiple if else statement checking if an object in the array is one which has a Game Studio defined for it
			if ((GameArray[i] instanceof VideoGame)){ 
				
				//if it does have a game studio like say the VideoGame Class, then it is compared to the initial game studio we wished to 
				//compare 
				if ((((VideoGame)GameArray[i]).getGameStudio().equals(GameStudiosame))){
					
					//if the game studios are the same the Game object is printed along with the index
					System.out.println("\n\nThis game has the Same Studio as the test case: \n" + GameArray[i] + "\nand the index is: " + i);
				}
			//same logic follows through this chunk of if-else
			}else if((GameArray[i] instanceof EducationalGame)) {
				
				if ((((EducationalGame)GameArray[i]).getGameStudio().equals(GameStudiosame))){
					
					System.out.println("\n\nThis game has the Same Studio as the test case: \n" + GameArray[i] + "\nand the index is: " + i);
				}
			}else if((GameArray[i] instanceof RPGGame)) {
				
				if ((((RPGGame)GameArray[i]).getGameStudio().equals(GameStudiosame))){
					
					System.out.println("\n\nThis game has the Same Studio as the test case: \n" + GameArray[i] + "\nand the index is: " + i);
				}
			}
		     
			}
			
		     //The Game objects in the Array with the Max number of players and the Min game Time are printed at the very end of the loop
		     //having thus compared every object
		     System.out.println("\n\nThis is the game with the max number of players: \n"+compareGame+"\nand the index is: "+Captureindex1);
		     System.out.println("\n\nThis is the game with the min game time: \n"+compareGame2+"\nand the index is: "+Captureindex2);
	
		     //copying using the copy constructor does not work to create a perfect copy.
		     //all objects copied with the copy constructor become of type Game 
		     //so attributes from other classes are lost and the only attributes copied are of type Game
		     //i.e. name, numPlayers, and game time.
		     
		     //call to the static method defined earlier
		     Game[] copyArray = driver.gameSimilarTo(GameArray);
		     
		     //2 for-each loops going over both arrays and seeing if each object in the arrays have the same attributes
		     for(Game game : GameArray) {
		    	 System.out.println("\n\nTHIS IS FROM GameArray: \n\n"+game);
		     }
		     for(Game game : copyArray) {
		    	 System.out.println("\n\nTHIS IS FROM copyArray: \n\n"+game);
		     }
	
		     System.out.print("Thank you for running the program! Have a nice day!");
	}

	

}
