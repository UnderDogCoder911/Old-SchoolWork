/**
 * 
 * @author Luca Stefanutti 40026602
 * COMP249
 * Assignment 3
 * Sunday August 4th 2019
 */
public class Cars {
	private String Make;
	private String Model;
	private int Year;
	private String color;
	private double price;
	
	
	
	/**
	 * Default constructor for Cars class
	 * @param make String for the make of the vehicle
	 * @param model String for the model of the vehicle
	 * @param year The production year in int of a vehicle
	 * @param color The color of a car in String
	 * @param price The price of a car in double
	 */
	public Cars(String make, String model, int year, String color, double price) {
		
		Make = make;
		Model = model;
		Year = year;
		this.color = color;
		this.price = price;
	}
	
	
	/**
	 * Getter for make parameter
	 * @return returns the make of a vehicle
	 */
	public String getMake() {
		return Make;
	}
	/**
	 * Setter for the make parameter 
	 * @param make String for the make that modifies the current make
	 */
	public void setMake(String make) {
		Make = make;
	}
	/**
	 * Getter for String model parameter
	 * @return returns the String for the model parameter
	 */
	public String getModel() {
		return Model;
	}
	/**
	 * Setter for String model parameter
	 * @param model takes a String to modify the model parameter
	 */
	public void setModel(String model) {
		Model = model;
	}
	/**
	 * Getter for the year parameter
	 * @return returns the year parameter as a int
	 */
	public int getYear() {
		return Year;
	}
	/**
	 * Setter for the year parameter
	 * @param year takes an int to modify the year parameter
	 */
	public void setYear(int year) {
		Year = year;
	}
	/**
	 * Getter for the String color parameter
	 * @return returns the color parameter as a String
	 */
	public String getColor() {
		return color;
	}
	/**
	 * Setter for color parameter
	 * @param color takes in a String to modify the color parameter
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * Getter for the price parameter
	 * @return returns a double for the price parameter
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * Setter for the parameter price
	 * @param price takes in a double to modify the price parameter
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
}
