
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class FileIO {
	
	static final int RECORDSIZEFORD = Integer.SIZE + ("Ford".length()+2) + Integer.SIZE + Double.SIZE;
	
	/*
	 * Assignment 3
	 * Question 2
	 * Written by Luca Stefanutti
	 */
	public static int MainMenu() {
		
		//Simple Main menu method which returns an int and prints out a choice for the 
		//various options
		
		Scanner kb = new Scanner(System.in);

		System.out.println("Please enter your choice: \n" + "1. List files\n" + "2. Process files\n" + "3. Exit");

		return kb.nextInt();
	}

	/*
	 * Assignment 3
	 * Question 1
	 * Written by Luca Stefanutti
	 */
	public static void listDirectories(File someFile)
			throws  EmptyFolderException, FileNotFoundException, InvalidFileException {
		Scanner kb = null;
		//Method that takes in a Directory
		File logFile = null;
		//creates a log file to store the files located in the directories
		 logFile = new File("Assignment3_Summer2019/log.txt");

		 kb = new Scanner(System.in);
		
		//If the log file exists and is a File to be written to
		//and if the file parameter passed is not null and is a Directory
		if(logFile.exists() && logFile.isFile()) {
			PrintWriter pw = new PrintWriter(new FileOutputStream(logFile, true));

			if (someFile == null || !(someFile.isDirectory())) {
				System.out.println("Directory not found, exiting");
				System.exit(0);
				
				//if it is indeed a Directory, the getAbstractPath() function is used
				//the file parameter and is stored into the log file
			} else if (someFile.isDirectory()) {

				pw.println("Directory: \n" + someFile.getAbsolutePath());
				
				//the files in the directory are stored in an array
				//using .listFiles on the parameter
				File[] filearray = someFile.listFiles();
				
				//If the array is empty, suggesting the folder is empty
				//the custom exception is thrown 
				if (filearray.length == 0) {
					kb.close();
					pw.close();
					throw new EmptyFolderException();
				}
				//If there are files in the folder
				//a for-each loop goes through all the files
				//in the array and stores their Absolute path within the
				//log file
				pw.println("Files: \n");
				for (File f : filearray) {
					pw.println(f.getAbsolutePath());
				}
				pw.close();
				
			}
			//if the log file does not exist or is not a file
			//a custom exception is thrown
		}else {
			throw new InvalidFileException("The log file cannot be found.");
		}
		
		//the recursion occurs at the end which takes in a String
		System.out.println("Please enter Directory path, no if you wish to end");
		String nextDir = kb.nextLine();
		
		//if the String is a no, the method exits back to main
		if (nextDir.equalsIgnoreCase("no")) {
			
			//kb.close();
			System.out.println("Returning to main menu");
			
		//Recursion occurs in case the string taken is not "no"
		//the String is taken and turned into the new Directory to be 
		//put into the log file
		} else {
			File anotherFile = new File(kb.nextLine());
			FileIO.listDirectories(anotherFile);
		}
		
	}

	public static void main(String[] args) {

		//The choice int which will control the while loop
		int choice = FileIO.MainMenu();
		
		//while the choice is between 1 and 3
		while (choice > 0 && choice < 4) {
			
			if (choice == 1) {
				//the first option takes in the 1st Directory by default
				File targetFile = new File("Assignment3_Summer2019/Data/2017");
				
				//the static method described above is called surrounded in a try catch block
				//once it is finished executing the Main menu is called again
				try {
					FileIO.listDirectories(targetFile);
					choice = FileIO.MainMenu();
				}
					//The custom exception must be written into the log file
					catch(InvalidFileException e) {
						try {
							//it must open a file so the catch for the exception must include a
							//a try catch for file not found exception
							PrintWriter pw = new PrintWriter(new FileOutputStream("Assignment3_Summer2019/log.txt", true));
							pw.println(e.getMessage());
							pw.close();
							System.exit(0);
						}

						catch (FileNotFoundException e1) {
							e1.printStackTrace();
							System.exit(0);
						}
					}
					//same logic for the 2nd custom exception as above
					catch (EmptyFolderException e) {

					try {
						PrintWriter pw = new PrintWriter(new FileOutputStream("Assignment3_Summer2019/log.txt", true));
						pw.println(e.getMessage());
						pw.close();
						System.exit(0);
					}

					catch (FileNotFoundException e2) {
						e2.printStackTrace();
						System.exit(0);
					}

				}

				catch (FileNotFoundException e) {
					e.printStackTrace();
					System.exit(0);
				}
				
				
			} else if (choice == 2) {
				
				//option 2 requires the log file to be processed
				File logFile = new File("Assignment3_Summer2019/log.txt");
				
				//the processed method (described below) is called and upon completion
				//the main menu is called again
				try {
					FileIO.Processing(logFile);
					choice = FileIO.MainMenu();
				
					//more custom exception needing to be written to
					//the log file
				} catch (InvalidFileException e) {
					try {
						PrintWriter pw = new PrintWriter(new FileOutputStream("Assignment3_Summer2019/log.txt", true));
						pw.println(e.getMessage());
						pw.close();
						System.exit(0);
					}

					catch (FileNotFoundException e1) {
						e1.printStackTrace();
						System.exit(0);
					}
					
				}catch (FileNotFoundException e) {
					e.printStackTrace();
					System.exit(0);
				
				}catch (IOException e) {
					e.printStackTrace();
					System.exit(0);
				}
			
				
				//option 3 exits the program
			} else if (choice == 3) {
				
				System.out.println("Thank you for using the program! Have a nice day!");
				System.exit(0);
			}
		}
	}
	/*
	*  Assignment 3
	 * Question 4
	 * Written by Luca Stefanutti
	*/
	public static void Processing(File theLog) throws IOException, InvalidFileException {
		
		//initalized Scanners, RandomAccessFile, ArrayList and File
		//to be used later
		Scanner FIS = null;
		Scanner FIS2 = null;
		RandomAccessFile RAF = null;
		File someText = null;
		ArrayList<Cars> myCarList = new ArrayList<Cars>(99);
		int i = 0;
		
		//if the log file passed through exists
		//and is a File to be written to
	if(theLog.exists() && theLog.isFile()) {
		
		//The Scanner will read throgh the logFile
		FIS = new Scanner(new FileInputStream(theLog));
		
		while(FIS.hasNextLine()) {
			
			//Most lines in the log file are absolute paths
			//to the txt files from which the info needs
			//to be extracted
			String Filename = FIS.nextLine();
			
			//all the information that is not a path to the 
			//txt files are ignored and passed over using continue
			if(Filename.equals("Directory: ") || Filename.equals("Files: ") 
				|| Filename.equals("Error, the Directory is empty.") || Filename.equals("The log file cannot be found.")
				|| Filename.equals("Error input file named XXX cannot be found.") || Filename.equals("")) {
				continue;
			
			//if the Line read from the log file is a
			//Absolute path to the txt files 
			}else {
				
				//then a new file is created using that path name
				someText = new File(Filename);
				
				//now the processing option isn't interested in Directories
				//so if the file created was a Directory we start back to the condition of the while loop
				if(someText.exists() && someText.isDirectory()) {
					continue;
				
				//now if it is a txt file
				}else if(someText.exists() && someText.isFile()) {
					
					//then another Scanner is initialized to read through that file
					FIS2 = new Scanner(new FileInputStream(someText));
					
					//as it goes through the various txt files it takes in the make
					//model, year, color and cost
					//notice that the cost must first be taken in as a String because in the
					//text files all prices have the $ sign in front
					//using Double.parseDouble() on the string minus the $ sign
					//the double value is extracted
					String make = FIS2.nextLine();
					String model = FIS2.nextLine();
					int year = FIS2.nextInt();
					FIS2.nextLine();
					String color = FIS2.nextLine();
					String textcost = FIS2.nextLine();
					String textactualcost = textcost.substring(1);
					double cost = Double.parseDouble(textactualcost);
					
					//all these values taken from the txt file are put into a Cars
					//object constructor
					Cars someCar = new Cars(make, model, year, color, cost);
					
					//and added to a arraylist which gradually appends new
					//Cars objects as the while loop goes through
					//the paths in the log files and
					//the txt files supply the data to create new objects
					myCarList.add(i, someCar);
					i++;
				
					//if the txt files read from the log files do not exist and are not files
					//then a custom exception is thrown
				}else if(!someText.exists() && !someText.isFile()){
					throw new InvalidFileException();
				}
				
			}
		}
		
		//similar custom exception is thrown, if the log file does not exist
		//and is not a file
		} else {
			throw new InvalidFileException("The log file cannot be found.");
		}
	
	
		//once all the information of the files are made into objects and stored
		//into the list, the Random Access file is created
		RAF = new RandomAccessFile("RandomAccess.dat", "rw");
		
		//The counts will get the nb of cars for each make, and the
		//cost will keep track of the total cost for each major make
		//note not all makes are taken into consideration
		//but can be with simple modification to the code
		int Fordcount = 0;
		double TotalFordCost = 0.0;
		
		int BMWcount = 0;
		double TotalBMWCost = 0.0;
		
		int Hondacount = 0;
		double TotalHondaCost = 0.0;
		
		int Audicount = 0;
		double TotalAudiCost = 0.0;
		
		int Toyotacount = 0;
		double TotalToyotaCost = 0.0;
		
		//going throught the Cars in myCarList
		for(Cars C : myCarList) {
			
			//depending on the make, the RandomAccessfile will be moved to a position
			//and will store the relevant information within the file
			//all while incrementing the total cost and the number of cars
			
			//if the same make is called upon twice it will override the values located at the byte 
			//positions at which they are being entered
			switch(C.getMake()) {
			
			case"Ford":
				//Ford info is stored at the beginning of the file 
				RAF.seek(0);
				int SRNOFord = 1;
				TotalFordCost += C.getPrice();
				Fordcount++;
				RAF.writeInt(SRNOFord);
				RAF.writeUTF(C.getMake());
				RAF.writeInt(Fordcount);
				RAF.writeDouble(TotalFordCost);
				break;
				
			case"BMW":
				//BMW is stored afterwards, this is done by adding the
				//size of each value in bits e.g. Integer is 4 bytes which is 32 bits
				//seeking through the RAF requires values in byte, hence the division by 8 at the end
				
				//6 represents the size of the String "Ford" which is 6 bytes 
				//1 for each character including the "s
				RAF.seek(((Integer.SIZE + Integer.SIZE + Double.SIZE)/8) + 6);
				int SRNOBMW = 2;
				TotalBMWCost += C.getPrice();
				BMWcount++;
				RAF.writeInt(SRNOBMW);
				RAF.writeUTF(C.getMake());
				RAF.writeInt(BMWcount);
				RAF.writeDouble(TotalBMWCost);
				break;
				
			case"Honda":
				//same logic applies for the following seek() as above, but now we're skipping over BMW
				//values hence the 2 * (bit size of values) + "Ford" + "BMW"
				RAF.seek(((2 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5);
				int SRNOHonda = 3;
				TotalHondaCost += C.getPrice();
				Hondacount++;
				RAF.writeInt(SRNOHonda);
				RAF.writeUTF(C.getMake());
				RAF.writeInt(Hondacount);
				RAF.writeDouble(TotalHondaCost);
				break;
				
			case"Toyota":
				//this logic stays the same for all the seek()
				RAF.seek(((3 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5 + 7);
				int SRNOToyota = 4;
				TotalToyotaCost += C.getPrice();
				Toyotacount++;
				RAF.writeInt(SRNOToyota);
				RAF.writeUTF(C.getMake());
				RAF.writeInt(Toyotacount);
				RAF.writeDouble(TotalToyotaCost);
				break;
				
			case"Audi":
				RAF.seek(((4 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5 + 7 + 8);
				int SRNOAudi = 5;
				TotalAudiCost += C.getPrice();
				Audicount++;
				RAF.writeInt(SRNOAudi);
				RAF.writeUTF(C.getMake());
				RAF.writeInt(Audicount);
				RAF.writeDouble(TotalAudiCost);
				break;
				
			
			//note that while going through the loop, A Toyota may be created before a Ford
			//the RandomAccessFile expands its length to allow this information to be written
			//even though it should not have that space originally
			//assuming a Ford entry isn't created
				
			//but even if say Ford is transcribed at the beginning, but then the next Car is an 
			//Audi which seeks past Ford, Honda, BMW, Toyota, its values will still be written
			//as the RandomAccessFile dynamically expands its length
			}	
			
		}
		
		//we then move the file pointer to where we wrote the information in the file
		//and read it back out to see if it has worked, which it has.
		RAF.seek(0);
		System.out.println("SRNO: " + RAF.readInt() + "\t CarMake: " + RAF.readUTF() + "\t NumOfCars: " + RAF.readInt() + "\t TotalCost: " + RAF.readDouble());
		
		RAF.seek(((Integer.SIZE + Integer.SIZE + Double.SIZE)/8) + 6);
		System.out.println("SRNO: " + RAF.readInt() + "\t CarMake: " + RAF.readUTF() + "\t NumOfCars: " + RAF.readInt() + "\t TotalCost: " + RAF.readDouble());
		
		RAF.seek(((2 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5);
		System.out.println("SRNO: " + RAF.readInt() + "\t CarMake: " + RAF.readUTF() + "\t NumOfCars: " + RAF.readInt() + "\t TotalCost: " + RAF.readDouble());
		
		RAF.seek(((3 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5 + 7);
		System.out.println("SRNO: " + RAF.readInt() + "\t CarMake: " + RAF.readUTF() + "\t NumOfCars: " + RAF.readInt() + "\t TotalCost: " + RAF.readDouble());
		
		RAF.seek(((4 * (Integer.SIZE + Integer.SIZE + Double.SIZE))/8) + 6 + 5 + 7 + 8);
		System.out.println("SRNO: " + RAF.readInt() + "\t CarMake: " + RAF.readUTF() + "\t NumOfCars: " + RAF.readInt() + "\t TotalCost: " + RAF.readDouble());
		
		RAF.close();
	}

}
