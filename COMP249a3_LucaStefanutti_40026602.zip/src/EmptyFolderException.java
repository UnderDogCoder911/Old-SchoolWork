import java.io.IOException;
/**
 * 
 * @author Luca Stefanutti 40026602
 * COMP249
 * Assignment 3, Question 3
 * Sunday August 4th 2019
 */
public class EmptyFolderException extends IOException{
	/**
	 * default constructor for the EmptyFolderException
	 */
	public EmptyFolderException() {
		super("Error, the Directory is empty.");
	}
	/**
	 * parameterized constructor for the EmptyFolderException
	 * @param msg takes in a Sting message which will be printed should the exception be thrown
	 */
	public EmptyFolderException(String msg) {
		super(msg);
	}
}
