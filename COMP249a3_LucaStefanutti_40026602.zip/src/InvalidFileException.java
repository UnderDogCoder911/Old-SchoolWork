import java.io.IOException;
/**
 * 
 * @author Luca Stefanutti 40026602
 * COMP249
 * Assignment 3, Question 3
 * Sunday August 4th 2019
 */
public class InvalidFileException extends IOException{

	/**
	 * default constructor for the InvalidFileException
	 */
	public InvalidFileException() {
		super("Error input file named XXX cannot be found.");
	}
	/**
	 * parameterized constructor for the InvalidFileException
	 * @param msg takes in a String which will be printed out should it be thrown
	 */
	public InvalidFileException(String msg) {
		super(msg);
	}
}
