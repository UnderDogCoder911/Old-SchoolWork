import java.io.*;
import java.util.Scanner;

public class FileScannertest {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner FIS2 = null;
		File someText = null;
		someText = new File("C:\\User\\workspace\\Assignment3COMP249\\Assignment3_Summer2019\\Data\\2017\\01.txt");
		
		FIS2 = new Scanner(new FileInputStream(someText));
		
		String make = FIS2.next();
		System.out.println(make);
		String model = FIS2.next();
		System.out.println(model);
		int year = FIS2.nextInt();
		System.out.println(year);
		FIS2.nextLine();
		String color = FIS2.next();
		System.out.println(color);
		String price = FIS2.next();
		String novoprice = price.substring(1);
		double actualprice = (double)Integer.parseInt(novoprice);
		System.out.println(actualprice);
	}



	

}
