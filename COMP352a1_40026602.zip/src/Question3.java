
public class Question3 {
	public static int count = 0;
	
	public static int[] MyAlgo(int[] myArray) {

		
		boolean done = true;
		int j = 0;
		
		
		while(j <= myArray.length - 2) {
			if(myArray[j] > myArray[j+1]) {
				int temp = myArray[j];
				myArray[j] = myArray[j+1];
				myArray[j+1] = temp; 
				done = false;
			}
			j++;
		}
		
		j = myArray.length - 1;
		
		while(j >= 1) {
			if(myArray[j] < myArray[j-1]) {
				int temp = myArray[j];
				myArray[j] = myArray[j-1];
				myArray[j-1] = temp; 
				done = false;
			}
			j--;
		}
		
		if(!done) {
			count++;
			MyAlgo(myArray);
		}
		
		return myArray;
		
		
		
		
	}

	public static void main(String[] args) {
		
		int [] myArray = {4, 11, 5, 3, 2, 6, 7, 10, 13, 0, 99, 31, 45, 21, 78, 88, 67, 32, 12, 69};
		
		int [] changeArray = MyAlgo(myArray);
		System.out.println("The count of executions is: " + count);
		
		for(int num : changeArray) {
			System.out.println(num);
		}
		

	}

}
