
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Tetranacci {
	public static long[] LinearTetra(int n) {
		
		if (n <= 1){
			long[] answer = {n, 0, 0, 0};
			return answer;
		}
		
		long [] temp = LinearTetra(n-1);
		long[] answer = {temp[0] + temp[1] + temp[2] + temp[3] , temp[0], temp[1], temp[2], temp[3]};
		return answer;
		
	}
	
	public static long MultiTetra(int n) {
		if(n <= 2) {
			return 0;
		}
		if (n == 3) {
			return 1;
		}
		return MultiTetra(n-1) + MultiTetra(n-2) + MultiTetra(n-3) + MultiTetra(n-4);
	}
	
	public static int TailTetra(int n, int nminus4, int nminus3, int nminus2, int nminus1) {
		
		int currentn = nminus4 + nminus3 + nminus2 + nminus1;
		
		if(n == 4) return currentn;
		
		return TailTetra(n-1, nminus3, nminus2, nminus1, currentn);
	}
	
	
	public static void main(String[] args) throws IOException {
		
		
		File output = new File("output.txt");
		
		output.createNewFile();
		
		FileWriter fw = new FileWriter(output, true);
		
		
	for (int n = 5; n < 105; n += 5) { 
		
		long start = System.nanoTime();
		long TheArray[] = LinearTetra(n);
		long end = System.nanoTime();
		
		fw.write("LinearTetra("+n+") = " + TheArray[2] +"\n"); //TheArray[0] + ", " + TheArray[1] + ", " + ", " + TheArray[3] + ", "+ TheArray[4] + "\n");
		fw.write("LinearTetra time in nanoseconds with n = " + n + " is " + (end - start) + "\n");
		
		}
	
	for (int n = 5; n < 40 ; n += 5) { 
		
		long start2 = System.nanoTime();
		long answer = MultiTetra(n);
		long end2 = System.nanoTime();
		
		fw.write("MultiTetra("+n+") = " + answer + "\n");
		fw.write("MultiTetra time in nanoseconds with n = " + n + " is " + (end2 - start2) + "\n");
	}
	
	for (int n = 5; n < 105; n += 5) { 
		
		long start3 = System.nanoTime();
		long TheAnswer = TailTetra(n, 0, 0, 0, 1);
		long end3 = System.nanoTime();
		
		fw.write("TailTetra("+n+") = " + TheAnswer + "\n");
		fw.write("TailTetra time in nanoseconds with n = " + n + " is " + (end3 - start3) + "\n");
		
	}
		fw.close(); 
	}

}
