ancestor(french(jean), B).
food(bread, X).
food(bread,X, milk).
mangaer(X).
meal(healthyFood(bread), drink(milk)).
meal(eat(Z), drink(milk)).
f(X, t(b,c)).
meal(healthyFood(bread), Y).
breakfast(healthyFood(bread), egg, milk).
dinner(X, Y, Time).
k(s(g), Y).
characters(hero(luke), X).
equation(Z, f(L, 17, M), L*M, 17).