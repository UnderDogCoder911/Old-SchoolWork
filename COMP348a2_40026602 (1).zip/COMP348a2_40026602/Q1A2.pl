team(['27296126', '40026602']).

student_info('27296126', 'Ian', 'Lopez').
student_info('40026602', 'Luca', 'Stefanutti').

takes_course('40026602', 'comp', '348', 'dd').
takes_course('40026602', 'comp', '348', 'dddd').
takes_course('40026602', 'comp', '352', 'h').
takes_course('40026602', 'comp', '352', 'hha').
takes_course('40026602', 'soen', '287', 'q').
takes_course('40026602', 'soen', '287', 'qqa').

takes_course('27296126', 'comp', '348', 'dd').
takes_course('27296126', 'comp', '348', 'dddb').
takes_course('27296126', 'comp', '345', 'd').
takes_course('27296126', 'comp', '345', 'bx').
takes_course('27296126', 'comp', '352', 'ff').
takes_course('27296126', 'comp', '352', 'fffb').
takes_course('27296126', 'encs', '282', 'a').
takes_course('27296126', 'encs', '282', 'aan').

course_schedule('comp', '348', 'dd','wed','1745','2015').
course_schedule('comp', '348', 'dddb','thu','1445','1535').
course_schedule('comp', '345', 'd', 'tue', '1315', '1430').
course_schedule('comp', '345', 'd', 'thu', '1315', '1430').
course_schedule('comp', '345', 'bx', 'wed', '2030', '2220').
course_schedule('comp', '352', 'ff', 'tue', '1745', '2015').
course_schedule('comp', '352', 'fffb', 'mon', '1145', '1235').
course_schedule('encs', '282', 'a', 'mon', '1615', '1730').
course_schedule('encs', '282', 'a', 'wed', '1615', '1730').
course_schedule('encs', '282', 'aan', 'mon', '1745', '1925').

course_schedule('comp', '348', 'dd', 'wed', '1745', '2015').
course_schedule('comp', '348', 'dddd', 'thu', '1545', '1635').
course_schedule('comp', '352', 'h', 'wed', '1315', '1430').
course_schedule('comp', '352', 'h', 'fri', '1315', '1430').
course_schedule('comp', '352', 'hha', 'wed', '1445', '1535').
course_schedule('soen', '287', 'q', 'tue', '1015', '1130').
course_schedule('soen', '287', 'q', 'thu', '1015', '1130').
course_schedule('soen', '287', 'qqa', 'tue', '1145', '1325').

all_sections(CNAM, CNUM, L) :- findall(X, takes_course(_, CNAM, CNUM, X), Lst), list_to_set(Lst, L).
 
has_taken(S, [CNAM|[CNUM|[SEC|[]]]]) :- takes_course(S, CNAM, CNUM, SEC).

has_taken2(S, [CNAM|[CNUM|[]]]) :- takes_course(S, CNAM, CNUM, _),!.

all_subjects(S, L) :- findall(CNAM, takes_course(S, CNAM, _, _), Lst),
    					list_to_set(Lst, L).

all_courses(S, L) :- findall([CNAM, CNUM, SEC], takes_course(S, CNAM, CNUM, SEC), L).

all_courses2(S, L) :- findall([CNAM, CNUM], takes_course(S, CNAM, CNUM, _), Lst),
    				list_to_set(Lst,L).
