#Ian Lopez 27296126
#Luca Stefenutti 40026602

class Device
  attr_accessor :category, :batteryLife, :modelNumber, :color, :manufacturer, :status, :year, :price, :features
  #Static variables @@
  @@DeviceNum = 0
  @@inventory = {}
  #Constructor (Parameterized)
  def initialize(cat, batL, modelNum, col, manuf, status, yr, price, feats)
    @category = cat
    @batteryLife = batL
    @modelNumber = modelNum
    @color = col
    @manufacturer = manuf
    @status = status
    @year = yr
    @price = price
    @features = feats  
    @@DeviceNum += 1
  end
#default Constructor
  def initialize()
    @@DeviceNum += 1
  end
#accessor for static array "inventory"
  def Device.inventory()
    @@inventory
  end
#Add to static inventory array
  def add_to_inventory()
    @@inventory[@@DeviceNum] = self 
  end

  def Device.count()
    @@DeviceNum
  end

  def To_String
    theString = "#{@category}, #{@batteryLife}, #{@modelNumber}, #{@color}, #{@manufacturer}, #{@status}, #{@year}, #{@price}, #{@features}\n"

    return theString
  end

end

def exportListing(someFile)

  fileMod = File.new(someFile, 'w')

Device.inventory.each do |x, y|
    fileMod.puts y.To_String
    fileMod.puts "\n"
  end

end

def getFileLines(someFile)
  content = someFile.readlines
  lines = {}

  y = 0

  for x in 0..content.length-1 do
    next if content[x].chomp == ""

    lines[y] = content[x].chomp
    y = y+1
  end

  return lines
end


def importListing(someFile)

  lines = getFileLines(someFile)


  for x in 0..lines.length-1 do
    line = lines[x]
    addToInventory(line)
  end

  items = []

Device.inventory.each do |x, y|
  items << y
  end

  items.sort_by { |a| [a.manufacturer, a.category, a.modelNumber]}

end


def addToInventory(line)

  theFeatures = ""

  for z in line.index("{")..line.index("}") do
    theFeatures += line[z]
  end

  entry = Device.new

  theFeatures = theFeatures.split(",")

  theFeatures.each do |x|
    x.capitalize
  end

  theFeatures = theFeatures.join(", ")

  entry.features = theFeatures

  line.slice!(theFeatures)

  line = line.split(",")

  line.delete("")

  for y in 0..line.length-1 do
    line[y] = line[y].strip 

    e = line[y].downcase

    if e.match(/[$]/)
      entry.price = line[y]
    elsif e.match("smartphone") || e.match('smartwatch') || e.match('tablet') || e.match('laptop')
      entry.category = line[y]

    elsif e.match("silver") || e.match("white") || e.match("black") || e.match("burgundy") || e.match("blue")
      entry.color = line[y]

    elsif e.match(/^\d{4}$/) 
      entry.year = line[y]
    elsif e =~ /hrs/
      entry.batteryLife = line[y]
    elsif e =~ /used|new|refurbished/
      entry.status = line[y]
    elsif e.match("apple") || e.match("samsung") || e.match("google") || e.match("lenovo") || e.match("lg")
      entry.manufacturer = line[y]
    elsif e.match(/^[\w]+$/)
      entry.modelNumber = line[y]
    end
  end #for1

  entry.add_to_inventory()
end


 
  puts "1: Show Inventory,\n 
  2: Import Listing \n 
  3: Export Listing \n
  4: Exit Program"

    puts "Enter a number between 1 and 4."

    user_in = gets

    user_in = user_in.to_i
    
while !(user_in >= 1 && user_in <= 4)
      puts "Invalid number!"
      
          puts "Please enter a number between 1 and 4."
      
          user_in = gets
      
          user_in = user_in.to_i
   end

while user_in >= 1 && user_in <= 4
   
  if user_in == 1

      puts "*****Showing Inventory:*****\n\n"

      Device.inventory.each do |x, y|
        puts y.To_String
        puts "\n"
      end

      puts "*******************\n"
   end

  if user_in == 2
      puts "Input file name for importing: "

      fileName = gets.chomp

      fileHandler = File.new(fileName, "r")
      

      puts "Importing the file!"

      importListing(fileHandler)
  end
  if user_in == 3
      puts "Input file name to export: "

      fileName = gets.chomp
      
      puts "Exporting the file!"

      exportListing(fileName)
  end
  if user_in == 4
      abort("-TERMINATE-")
  end
   
  puts "1: Show Inventory,\n 
   2: Import Listing \n 
   3: Export Listing \n
   4: Exit Program"
 
     puts "Enter a number between 1 and 4."
 
     user_in = gets
 
     user_in = user_in.to_i
     
  while !(user_in >= 1 && user_in <= 4)
        puts "Invalid number!"
        
            puts "Please enter a number between 1 and 4."
        
            user_in = gets
        
            user_in = user_in.to_i
     end
   
  end




