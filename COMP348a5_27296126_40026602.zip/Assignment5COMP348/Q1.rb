
if ARGV.length == 0
    puts "Error, please type the name of the file to be read into the command line"
    exit(0)
else
    Filename = ARGV[0]
    puts"Success"
end

myFile = File.new(Filename, 'r')


lines = myFile.readlines

text = lines.join()



charArray = text.split(/\s*/)

numChars = charArray.length

puts "The number of Characters is: #{numChars}"


WordsArr = text.split(/\W+/)

numWords = WordsArr.length

puts "The number of Words is: #{numWords}"


SentenceArr = text.split(/[(.|;)]+/)

numSentences = SentenceArr.length

puts "The number of Sentences is: #{numSentences}"


ParagraphArr = text.split(/[\r\n]{2,}/)

numParagraphs = ParagraphArr.length

puts "The number of Paragraphs is: #{numParagraphs}"


PageArr = text.split(/[\r\n]{50,}/)

numPages = PageArr.length

puts "The number of Pages is #{numPages}\n"


AvrwordSize = (numChars/(numWords.to_f)).round(2)

puts "The average word size is #{AvrwordSize} chars/word"


AvrsentenceSize = (numWords/(numSentences.to_f)).round(2)

puts "The average sentence size is #{AvrsentenceSize} words/sentence"


AvrparagraphSize = (numSentences/(numParagraphs.to_f)).round(2)
  
puts "The average Paragraph size is #{AvrparagraphSize} sentences/paragraph"


AvrparasperPage = (numPages/(numParagraphs.to_f)).round(2)
  
puts "The Average Paragraphs per Page is #{AvrparasperPage}"


TotalBytes = text.bytesize

puts "The Total Bytes in the file are #{TotalBytes}"


CharDen = (numChars/(TotalBytes.to_f)).round(2)
  
puts "The Density of Characters is #{CharDen} Chars/Byte" 

myFile.close